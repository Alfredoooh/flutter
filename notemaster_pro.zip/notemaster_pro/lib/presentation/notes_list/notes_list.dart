import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/batch_operations_toolbar_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/note_card_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/view_mode_selector_widget.dart';

class NotesList extends StatefulWidget {
  const NotesList({super.key});

  @override
  State<NotesList> createState() => _NotesListState();
}

class _NotesListState extends State<NotesList> with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // State variables
  String _searchQuery = '';
  String _sortBy = 'date';
  String _viewMode = 'list';
  bool _isMultiSelectMode = false;
  final Set<int> _selectedNotes = {};
  List<Map<String, dynamic>> _filteredNotes = [];
  bool _isLoading = false;

  // Mock data for notes
  final List<Map<String, dynamic>> _allNotes = [
    {
      "id": 1,
      "title": "Meeting Notes - Q4 Planning",
      "content":
          "Discussed quarterly goals, budget allocation, and team restructuring. Key decisions made regarding product roadmap and resource allocation for next quarter.",
      "category": "Work",
      "categoryColor": Color(0xFF007AFF),
      "createdAt": DateTime.now().subtract(Duration(hours: 2)),
      "modifiedAt": DateTime.now().subtract(Duration(hours: 1)),
      "size": "2.3 KB",
      "isPinned": true,
      "isArchived": false,
      "tags": ["meeting", "planning", "work"]
    },
    {
      "id": 2,
      "title": "Trading Strategy Analysis",
      "content":
          "Analysis of recent market trends and trading performance. Risk management strategies and portfolio diversification notes for upcoming trades.",
      "category": "Finance",
      "categoryColor": Color(0xFF34C759),
      "createdAt": DateTime.now().subtract(Duration(days: 1)),
      "modifiedAt": DateTime.now().subtract(Duration(hours: 12)),
      "size": "4.7 KB",
      "isPinned": false,
      "isArchived": false,
      "tags": ["trading", "finance", "strategy"]
    },
    {
      "id": 3,
      "title": "Flutter Development Tips",
      "content":
          "Collection of useful Flutter widgets, best practices, and performance optimization techniques. State management patterns and testing strategies.",
      "category": "Development",
      "categoryColor": Color(0xFF5856D6),
      "createdAt": DateTime.now().subtract(Duration(days: 2)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 1)),
      "size": "6.1 KB",
      "isPinned": true,
      "isArchived": false,
      "tags": ["flutter", "development", "tips"]
    },
    {
      "id": 4,
      "title": "Book Ideas & Concepts",
      "content":
          "Creative writing ideas, character development notes, and plot outlines for upcoming novel. Research notes on historical settings and themes.",
      "category": "Personal",
      "categoryColor": Color(0xFFFF9500),
      "createdAt": DateTime.now().subtract(Duration(days: 3)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 2)),
      "size": "3.2 KB",
      "isPinned": false,
      "isArchived": false,
      "tags": ["writing", "creative", "ideas"]
    },
    {
      "id": 5,
      "title": "Grocery List & Meal Planning",
      "content":
          "Weekly grocery list with meal prep ideas. Healthy recipes and nutritional information for balanced diet planning.",
      "category": "Personal",
      "categoryColor": Color(0xFFFF9500),
      "createdAt": DateTime.now().subtract(Duration(days: 4)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 3)),
      "size": "1.8 KB",
      "isPinned": false,
      "isArchived": false,
      "tags": ["grocery", "meal", "health"]
    },
    {
      "id": 6,
      "title": "Investment Portfolio Review",
      "content":
          "Quarterly portfolio performance analysis, asset allocation review, and rebalancing strategies. Market outlook and investment opportunities.",
      "category": "Finance",
      "categoryColor": Color(0xFF34C759),
      "createdAt": DateTime.now().subtract(Duration(days: 5)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 4)),
      "size": "5.4 KB",
      "isPinned": false,
      "isArchived": false,
      "tags": ["investment", "portfolio", "finance"]
    },
    {
      "id": 7,
      "title": "Travel Itinerary - Europe Trip",
      "content":
          "Detailed travel plans for European vacation. Hotel bookings, flight information, and must-visit attractions in each city.",
      "category": "Travel",
      "categoryColor": Color(0xFFAF52DE),
      "createdAt": DateTime.now().subtract(Duration(days: 6)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 5)),
      "size": "7.2 KB",
      "isPinned": true,
      "isArchived": false,
      "tags": ["travel", "europe", "vacation"]
    },
    {
      "id": 8,
      "title": "Workout Routine & Progress",
      "content":
          "Daily workout schedules, exercise routines, and fitness progress tracking. Nutrition plans and health goals for the month.",
      "category": "Health",
      "categoryColor": Color(0xFFFF3B30),
      "createdAt": DateTime.now().subtract(Duration(days: 7)),
      "modifiedAt": DateTime.now().subtract(Duration(days: 6)),
      "size": "2.9 KB",
      "isPinned": false,
      "isArchived": false,
      "tags": ["workout", "fitness", "health"]
    }
  ];

  @override
  void initState() {
    super.initState();
    _filteredNotes = List.from(_allNotes);
    _sortNotes();
    _searchController.addListener(_onSearchChanged);
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text;
      _filterNotes();
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _loadMoreNotes();
    }
  }

  void _filterNotes() {
    setState(() {
      if (_searchQuery.isEmpty) {
        _filteredNotes = List.from(_allNotes);
      } else {
        _filteredNotes = _allNotes.where((note) {
          final title = (note['title'] as String).toLowerCase();
          final content = (note['content'] as String).toLowerCase();
          final tags = (note['tags'] as List).join(' ').toLowerCase();
          final query = _searchQuery.toLowerCase();

          return title.contains(query) ||
              content.contains(query) ||
              tags.contains(query);
        }).toList();
      }
      _sortNotes();
    });
  }

  void _sortNotes() {
    setState(() {
      switch (_sortBy) {
        case 'date':
          _filteredNotes.sort((a, b) => (b['modifiedAt'] as DateTime)
              .compareTo(a['modifiedAt'] as DateTime));
          break;
        case 'title':
          _filteredNotes.sort(
              (a, b) => (a['title'] as String).compareTo(b['title'] as String));
          break;
        case 'size':
          _filteredNotes.sort((a, b) => _parseSize(b['size'] as String)
              .compareTo(_parseSize(a['size'] as String)));
          break;
        case 'category':
          _filteredNotes.sort((a, b) =>
              (a['category'] as String).compareTo(b['category'] as String));
          break;
      }

      // Move pinned notes to top
      final pinnedNotes =
          _filteredNotes.where((note) => note['isPinned'] == true).toList();
      final unpinnedNotes =
          _filteredNotes.where((note) => note['isPinned'] != true).toList();
      _filteredNotes = [...pinnedNotes, ...unpinnedNotes];
    });
  }

  double _parseSize(String sizeStr) {
    final parts = sizeStr.split(' ');
    final value = double.tryParse(parts[0]) ?? 0;
    final unit = parts.length > 1 ? parts[1] : 'KB';

    switch (unit.toUpperCase()) {
      case 'MB':
        return value * 1024;
      case 'GB':
        return value * 1024 * 1024;
      default:
        return value;
    }
  }

  void _loadMoreNotes() {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    // Simulate loading delay
    Future.delayed(Duration(seconds: 1), () {
      setState(() {
        _isLoading = false;
      });
    });
  }

  Future<void> _refreshNotes() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate refresh delay
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _filteredNotes = List.from(_allNotes);
      _sortNotes();
      _isLoading = false;
    });
  }

  void _toggleMultiSelect() {
    setState(() {
      _isMultiSelectMode = !_isMultiSelectMode;
      if (!_isMultiSelectMode) {
        _selectedNotes.clear();
      }
    });
  }

  void _toggleNoteSelection(int noteId) {
    setState(() {
      if (_selectedNotes.contains(noteId)) {
        _selectedNotes.remove(noteId);
      } else {
        _selectedNotes.add(noteId);
      }

      if (_selectedNotes.isEmpty) {
        _isMultiSelectMode = false;
      }
    });
  }

  void _showSortOptions() {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: Text('Sort Notes By'),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              setState(() {
                _sortBy = 'date';
                _sortNotes();
              });
              Navigator.pop(context);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Date Modified'),
                _sortBy == 'date'
                    ? CustomIconWidget(
                        iconName: 'check',
                        color: AppTheme.primaryLight,
                        size: 20,
                      )
                    : SizedBox(),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              setState(() {
                _sortBy = 'title';
                _sortNotes();
              });
              Navigator.pop(context);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Title'),
                _sortBy == 'title'
                    ? CustomIconWidget(
                        iconName: 'check',
                        color: AppTheme.primaryLight,
                        size: 20,
                      )
                    : SizedBox(),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              setState(() {
                _sortBy = 'size';
                _sortNotes();
              });
              Navigator.pop(context);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('File Size'),
                _sortBy == 'size'
                    ? CustomIconWidget(
                        iconName: 'check',
                        color: AppTheme.primaryLight,
                        size: 20,
                      )
                    : SizedBox(),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              setState(() {
                _sortBy = 'category';
                _sortNotes();
              });
              Navigator.pop(context);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Category'),
                _sortBy == 'category'
                    ? CustomIconWidget(
                        iconName: 'check',
                        color: AppTheme.primaryLight,
                        size: 20,
                      )
                    : SizedBox(),
              ],
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
      ),
    );
  }

  void _showBatchOperations() {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: Text('Batch Operations (${_selectedNotes.length} selected)'),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _batchArchive();
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'archive',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Archive Selected'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _batchPin();
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'push_pin',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Pin Selected'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _batchShare();
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'share',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Share Selected'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showDeleteConfirmation();
            },
            isDestructiveAction: true,
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'delete',
                  color: AppTheme.errorLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Delete Selected'),
              ],
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
      ),
    );
  }

  void _showDeleteConfirmation() {
    showCupertinoDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text('Delete Notes'),
        content: Text(
            'Are you sure you want to delete ${_selectedNotes.length} selected notes? This action cannot be undone.'),
        actions: [
          CupertinoDialogAction(
            child: Text('Cancel'),
            onPressed: () => Navigator.pop(context),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: Text('Delete'),
            onPressed: () {
              Navigator.pop(context);
              _batchDelete();
            },
          ),
        ],
      ),
    );
  }

  void _batchArchive() {
    setState(() {
      _selectedNotes.clear();
      _isMultiSelectMode = false;
    });
    _showSnackBar('Notes archived successfully');
  }

  void _batchPin() {
    setState(() {
      _selectedNotes.clear();
      _isMultiSelectMode = false;
    });
    _showSnackBar('Notes pinned successfully');
  }

  void _batchShare() {
    setState(() {
      _selectedNotes.clear();
      _isMultiSelectMode = false;
    });
    _showSnackBar('Notes shared successfully');
  }

  void _batchDelete() {
    setState(() {
      _selectedNotes.clear();
      _isMultiSelectMode = false;
    });
    _showSnackBar('Notes deleted successfully');
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Notes',
          style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        elevation: 0,
        actions: [
          if (_isMultiSelectMode) ...[
            TextButton(
              onPressed: _showBatchOperations,
              child: Text('Actions'),
            ),
            TextButton(
              onPressed: _toggleMultiSelect,
              child: Text('Cancel'),
            ),
          ] else ...[
            IconButton(
              onPressed: _showSortOptions,
              icon: CustomIconWidget(
                iconName: 'sort',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
            ),
            IconButton(
              onPressed: () => Navigator.pushNamed(context, '/settings'),
              icon: CustomIconWidget(
                iconName: 'settings',
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
            ),
          ],
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          SearchBarWidget(
            controller: _searchController,
            onFilterPressed: () =>
                Navigator.pushNamed(context, '/search-results'),
          ),

          // View Mode Selector
          ViewModeSelectorWidget(
            selectedMode: _viewMode,
            onModeChanged: (mode) {
              setState(() {
                _viewMode = mode;
              });
            },
          ),

          // Notes List
          Expanded(
            child: _filteredNotes.isEmpty
                ? EmptyStateWidget(
                    hasSearchQuery: _searchQuery.isNotEmpty,
                    onCreateNote: () =>
                        Navigator.pushNamed(context, '/note-editor'),
                  )
                : RefreshIndicator(
                    onRefresh: _refreshNotes,
                    child: ListView.builder(
                      controller: _scrollController,
                      padding:
                          EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                      itemCount: _filteredNotes.length + (_isLoading ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == _filteredNotes.length) {
                          return Container(
                            padding: EdgeInsets.all(4.w),
                            child: Center(
                              child: CupertinoActivityIndicator(),
                            ),
                          );
                        }

                        final note = _filteredNotes[index];
                        final isSelected = _selectedNotes.contains(note['id']);

                        return NoteCardWidget(
                          note: note,
                          viewMode: _viewMode,
                          isMultiSelectMode: _isMultiSelectMode,
                          isSelected: isSelected,
                          searchQuery: _searchQuery,
                          onTap: () {
                            if (_isMultiSelectMode) {
                              _toggleNoteSelection(note['id']);
                            } else {
                              Navigator.pushNamed(context, '/note-editor');
                            }
                          },
                          onLongPress: () {
                            if (!_isMultiSelectMode) {
                              setState(() {
                                _isMultiSelectMode = true;
                                _selectedNotes.add(note['id']);
                              });
                            }
                          },
                          onSwipeLeft: () => _showArchiveDeleteOptions(note),
                          onSwipeRight: () =>
                              _showPinDuplicateShareOptions(note),
                        );
                      },
                    ),
                  ),
          ),

          // Batch Operations Toolbar
          if (_isMultiSelectMode)
            BatchOperationsToolbarWidget(
              selectedCount: _selectedNotes.length,
              onArchive: _batchArchive,
              onPin: _batchPin,
              onShare: _batchShare,
              onDelete: () => _showDeleteConfirmation(),
            ),
        ],
      ),
      floatingActionButton: _isMultiSelectMode
          ? null
          : FloatingActionButton(
              onPressed: () => Navigator.pushNamed(context, '/note-editor'),
              backgroundColor: AppTheme.lightTheme.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: CustomIconWidget(
                iconName: 'add',
                color: Colors.white,
                size: 24,
              ),
            ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: 1, // Notes tab active
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/main-dashboard');
              break;
            case 1:
              // Already on notes list
              break;
            case 2:
              Navigator.pushNamed(context, '/trading-recovery-calculator');
              break;
            case 3:
              Navigator.pushNamed(context, '/settings');
              break;
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'dashboard',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            activeIcon: CustomIconWidget(
              iconName: 'dashboard',
              color: AppTheme.lightTheme.primaryColor,
              size: 24,
            ),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'note',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            activeIcon: CustomIconWidget(
              iconName: 'note',
              color: AppTheme.lightTheme.primaryColor,
              size: 24,
            ),
            label: 'Notes',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'calculate',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            activeIcon: CustomIconWidget(
              iconName: 'calculate',
              color: AppTheme.lightTheme.primaryColor,
              size: 24,
            ),
            label: 'Calculator',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'settings',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            activeIcon: CustomIconWidget(
              iconName: 'settings',
              color: AppTheme.lightTheme.primaryColor,
              size: 24,
            ),
            label: 'Settings',
          ),
        ],
      ),
    );
  }

  void _showArchiveDeleteOptions(Map<String, dynamic> note) {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: Text(note['title']),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar('Note archived');
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'archive',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Archive'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showSingleDeleteConfirmation(note);
            },
            isDestructiveAction: true,
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'delete',
                  color: AppTheme.errorLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Delete'),
              ],
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
      ),
    );
  }

  void _showPinDuplicateShareOptions(Map<String, dynamic> note) {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: Text(note['title']),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar(note['isPinned'] ? 'Note unpinned' : 'Note pinned');
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: note['isPinned'] ? 'push_pin_outlined' : 'push_pin',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text(note['isPinned'] ? 'Unpin' : 'Pin'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar('Note duplicated');
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'content_copy',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Duplicate'),
              ],
            ),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar('Note shared');
            },
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'share',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 12),
                Text('Share'),
              ],
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
      ),
    );
  }

  void _showSingleDeleteConfirmation(Map<String, dynamic> note) {
    showCupertinoDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text('Delete Note'),
        content: Text(
            'Are you sure you want to delete "${note['title']}"? This action cannot be undone.'),
        actions: [
          CupertinoDialogAction(
            child: Text('Cancel'),
            onPressed: () => Navigator.pop(context),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: Text('Delete'),
            onPressed: () {
              Navigator.pop(context);
              _showSnackBar('Note deleted');
            },
          ),
        ],
      ),
    );
  }
}
