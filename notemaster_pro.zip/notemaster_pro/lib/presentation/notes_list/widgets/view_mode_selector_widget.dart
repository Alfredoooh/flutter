import 'package:flutter/cupertino.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ViewModeSelectorWidget extends StatelessWidget {
  final String selectedMode;
  final Function(String) onModeChanged;

  const ViewModeSelectorWidget({
    super.key,
    required this.selectedMode,
    required this.onModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: Row(
        children: [
          Expanded(
            child: CupertinoSlidingSegmentedControl<String>(
              groupValue: selectedMode,
              onValueChanged: (value) {
                if (value != null) {
                  onModeChanged(value);
                }
              },
              children: {
                'list': Padding(
                  padding: EdgeInsets.symmetric(vertical: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'list',
                        color: selectedMode == 'list'
                            ? AppTheme.lightTheme.primaryColor
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        'List',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: selectedMode == 'list'
                              ? AppTheme.lightTheme.primaryColor
                              : AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                          fontWeight: selectedMode == 'list'
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                'grid': Padding(
                  padding: EdgeInsets.symmetric(vertical: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'grid_view',
                        color: selectedMode == 'grid'
                            ? AppTheme.lightTheme.primaryColor
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        'Grid',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: selectedMode == 'grid'
                              ? AppTheme.lightTheme.primaryColor
                              : AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                          fontWeight: selectedMode == 'grid'
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                'compact': Padding(
                  padding: EdgeInsets.symmetric(vertical: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'view_compact',
                        color: selectedMode == 'compact'
                            ? AppTheme.lightTheme.primaryColor
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        'Compact',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: selectedMode == 'compact'
                              ? AppTheme.lightTheme.primaryColor
                              : AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                          fontWeight: selectedMode == 'compact'
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              },
            ),
          ),
        ],
      ),
    );
  }
}
