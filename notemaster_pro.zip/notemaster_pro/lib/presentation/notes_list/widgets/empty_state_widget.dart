import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyStateWidget extends StatelessWidget {
  final bool hasSearchQuery;
  final VoidCallback onCreateNote;

  const EmptyStateWidget({
    super.key,
    required this.hasSearchQuery,
    required this.onCreateNote,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30.w,
              height: 30.w,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: hasSearchQuery ? 'search_off' : 'note_add',
                color: AppTheme.lightTheme.primaryColor,
                size: 15.w,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              hasSearchQuery ? 'No results found' : 'No notes yet',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              hasSearchQuery
                  ? 'Try adjusting your search terms or create a new note with this content.'
                  : 'Start capturing your thoughts, ideas, and important information. Tap the + button to create your first note.',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),
            if (!hasSearchQuery)
              ElevatedButton.icon(
                onPressed: onCreateNote,
                icon: CustomIconWidget(
                  iconName: 'add',
                  color: Colors.white,
                  size: 20,
                ),
                label: Text('Create Your First Note'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.primaryColor,
                  foregroundColor: Colors.white,
                  padding:
                      EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.5.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            if (hasSearchQuery)
              OutlinedButton.icon(
                onPressed: onCreateNote,
                icon: CustomIconWidget(
                  iconName: 'add',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 20,
                ),
                label: Text('Create Note'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.lightTheme.primaryColor,
                  side: BorderSide(color: AppTheme.lightTheme.primaryColor),
                  padding:
                      EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.5.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
