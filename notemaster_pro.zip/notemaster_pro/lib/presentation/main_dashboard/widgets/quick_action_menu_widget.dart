import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class QuickActionMenuWidget extends StatefulWidget {
  final Function(String) onActionSelected;
  final VoidCallback onClose;

  const QuickActionMenuWidget({
    super.key,
    required this.onActionSelected,
    required this.onClose,
  });

  @override
  State<QuickActionMenuWidget> createState() => _QuickActionMenuWidgetState();
}

class _QuickActionMenuWidgetState extends State<QuickActionMenuWidget>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  final List<Map<String, dynamic>> quickActions = [
    {
      'id': 'new_note',
      'title': 'New Note',
      'icon': 'note_add',
      'color': const Color(0xFF007AFF),
    },
    {
      'id': 'voice_note',
      'title': 'Voice Note',
      'icon': 'mic',
      'color': const Color(0xFF34C759),
    },
    {
      'id': 'camera_ocr',
      'title': 'Scan Text',
      'icon': 'camera_alt',
      'color': const Color(0xFF5856D6),
    },
    {
      'id': 'trading_calculator',
      'title': 'Calculator',
      'icon': 'calculate',
      'color': const Color(0xFFFF9500),
    },
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.elasticOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleActionTap(String actionId) {
    _animationController.reverse().then((_) {
      widget.onActionSelected(actionId);
    });
  }

  void _handleBackgroundTap() {
    _animationController.reverse().then((_) {
      widget.onClose();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: GestureDetector(
        onTap: _handleBackgroundTap,
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Container(
              color: Colors.black.withValues(alpha: 0.3 * _fadeAnimation.value),
              child: Stack(
                children: [
                  // Quick action buttons positioned around FAB
                  for (int i = 0; i < quickActions.length; i++)
                    _buildQuickActionButton(
                      quickActions[i],
                      i,
                      quickActions.length,
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildQuickActionButton(
    Map<String, dynamic> action,
    int index,
    int totalActions,
  ) {
    // Calculate position in a semi-circle above the FAB
    final double angle = (index / (totalActions - 1)) * 3.14159; // 180 degrees
    final double radius = 20.w;
    final double fabX = 85.w; // FAB position
    final double fabY = 85.h; // FAB position

    final double x = fabX - (radius * (1 - angle / 3.14159)) - 6.w;
    final double y = fabY - (radius * (angle / 3.14159).abs()) - 6.h;

    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Positioned(
          left: x,
          top: y,
          child: Transform.scale(
            scale: _scaleAnimation.value,
            child: Opacity(
              opacity: _fadeAnimation.value,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Action button
                  GestureDetector(
                    onTap: () => _handleActionTap(action['id']),
                    child: Container(
                      width: 12.w,
                      height: 12.w,
                      decoration: BoxDecoration(
                        color: action['color'],
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: action['color'].withValues(alpha: 0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Center(
                        child: CustomIconWidget(
                          iconName: action['icon'],
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 1.h),

                  // Action label
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: Theme.of(context)
                              .colorScheme
                              .shadow
                              .withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      action['title'],
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurface,
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
