import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/quick_action_menu_widget.dart';
import './widgets/quick_stats_card_widget.dart';
import './widgets/recent_note_card_widget.dart';

class MainDashboard extends StatefulWidget {
  const MainDashboard({super.key});

  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard>
    with TickerProviderStateMixin {
  int _selectedIndex = 0;
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _showQuickActionMenu = false;
  late AnimationController _fabAnimationController;
  late Animation<double> _fabAnimation;

  // Mock data for notes
  final List<Map<String, dynamic>> recentNotes = [
    {
      "id": 1,
      "title": "Meeting Notes - Q4 Planning",
      "preview":
          "Discussed quarterly goals, budget allocation, and team restructuring. Key points include...",
      "lastModified": DateTime.now().subtract(const Duration(hours: 2)),
      "category": "Work",
      "categoryColor": const Color(0xFF007AFF),
      "isPinned": true,
      "wordCount": 245,
    },
    {
      "id": 2,
      "title": "Trading Strategy Analysis",
      "preview":
          "Market analysis for crypto portfolio. Bitcoin showing strong resistance at \$45,000 level...",
      "lastModified": DateTime.now().subtract(const Duration(days: 1)),
      "category": "Finance",
      "categoryColor": const Color(0xFF34C759),
      "isPinned": false,
      "wordCount": 189,
    },
    {
      "id": 3,
      "title": "Flutter Development Tips",
      "preview":
          "Best practices for state management, widget optimization, and performance improvements...",
      "lastModified": DateTime.now().subtract(const Duration(days: 2)),
      "category": "Development",
      "categoryColor": const Color(0xFF5856D6),
      "isPinned": false,
      "wordCount": 312,
    },
    {
      "id": 4,
      "title": "Grocery List",
      "preview":
          "Weekly shopping: Milk, Bread, Eggs, Vegetables, Fruits, Chicken, Rice...",
      "lastModified": DateTime.now().subtract(const Duration(days: 3)),
      "category": "Personal",
      "categoryColor": const Color(0xFFFF9500),
      "isPinned": false,
      "wordCount": 45,
    },
    {
      "id": 5,
      "title": "Book Ideas Collection",
      "preview":
          "Collection of interesting book recommendations from friends and online reviews...",
      "lastModified": DateTime.now().subtract(const Duration(days: 5)),
      "category": "Reading",
      "categoryColor": const Color(0xFFAF52DE),
      "isPinned": true,
      "wordCount": 156,
    },
  ];

  // Mock stats data
  final Map<String, dynamic> statsData = {
    "totalNotes": 127,
    "recentActivity": 8,
    "storageUsed": "2.4 MB",
    "storageTotal": "100 MB",
    "storagePercentage": 0.024,
  };

  @override
  void initState() {
    super.initState();
    _fabAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fabAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fabAnimationController, curve: Curves.easeInOut),
    );
    _fabAnimationController.forward();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _fabAnimationController.dispose();
    super.dispose();
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Dashboard - already here
        break;
      case 1:
        Navigator.pushNamed(context, '/notes-list');
        break;
      case 2:
        Navigator.pushNamed(context, '/trading-recovery-calculator');
        break;
      case 3:
        Navigator.pushNamed(context, '/settings');
        break;
    }
  }

  void _toggleSearch() {
    setState(() {
      _isSearching = !_isSearching;
      if (!_isSearching) {
        _searchController.clear();
      }
    });
  }

  void _onSearchSubmitted(String query) {
    if (query.isNotEmpty) {
      Navigator.pushNamed(context, '/search-results');
    }
  }

  void _toggleQuickActionMenu() {
    setState(() {
      _showQuickActionMenu = !_showQuickActionMenu;
    });
  }

  void _onQuickActionSelected(String action) {
    setState(() {
      _showQuickActionMenu = false;
    });

    switch (action) {
      case 'new_note':
        Navigator.pushNamed(context, '/note-editor');
        break;
      case 'voice_note':
        // Handle voice note creation
        break;
      case 'camera_ocr':
        // Handle camera OCR
        break;
      case 'trading_calculator':
        Navigator.pushNamed(context, '/trading-recovery-calculator');
        break;
    }
  }

  Future<void> _onRefresh() async {
    // Simulate refresh delay
    await Future.delayed(const Duration(seconds: 1));
    // In real app, this would sync with local storage or cloud
  }

  void _onNoteCardTap(Map<String, dynamic> note) {
    Navigator.pushNamed(context, '/note-editor');
  }

  void _onNoteCardLongPress(Map<String, dynamic> note) {
    _showNoteContextMenu(note);
  }

  void _showNoteContextMenu(Map<String, dynamic> note) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildContextMenuItem(
                    icon: 'edit',
                    title: 'Edit Note',
                    onTap: () {
                      Navigator.pop(context);
                      _onNoteCardTap(note);
                    },
                  ),
                  _buildContextMenuItem(
                    icon: note['isPinned'] ? 'push_pin' : 'push_pin_outlined',
                    title: note['isPinned'] ? 'Unpin' : 'Pin',
                    onTap: () {
                      Navigator.pop(context);
                      // Handle pin/unpin
                    },
                  ),
                  _buildContextMenuItem(
                    icon: 'share',
                    title: 'Share',
                    onTap: () {
                      Navigator.pop(context);
                      // Handle share
                    },
                  ),
                  _buildContextMenuItem(
                    icon: 'archive',
                    title: 'Archive',
                    onTap: () {
                      Navigator.pop(context);
                      // Handle archive
                    },
                  ),
                  _buildContextMenuItem(
                    icon: 'delete',
                    title: 'Delete',
                    color: Theme.of(context).colorScheme.error,
                    onTap: () {
                      Navigator.pop(context);
                      // Handle delete
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: MediaQuery.of(context).padding.bottom),
          ],
        ),
      ),
    );
  }

  Widget _buildContextMenuItem({
    required String icon,
    required String title,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: color ?? Theme.of(context).colorScheme.onSurface,
        size: 24,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: color,
            ),
      ),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Search Bar
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 6.h,
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Theme.of(context)
                                  .colorScheme
                                  .outline
                                  .withValues(alpha: 0.2),
                            ),
                          ),
                          child: TextField(
                            controller: _searchController,
                            decoration: InputDecoration(
                              hintText: 'Search notes...',
                              prefixIcon: Padding(
                                padding: const EdgeInsets.all(12),
                                child: CustomIconWidget(
                                  iconName: 'search',
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant,
                                  size: 20,
                                ),
                              ),
                              suffixIcon: Padding(
                                padding: const EdgeInsets.all(12),
                                child: CustomIconWidget(
                                  iconName: 'mic',
                                  color: Theme.of(context).colorScheme.primary,
                                  size: 20,
                                ),
                              ),
                              border: InputBorder.none,
                              contentPadding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                            onSubmitted: _onSearchSubmitted,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Quick Stats Cards
                Container(
                  height: 12.h,
                  margin: EdgeInsets.only(bottom: 2.h),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    children: [
                      QuickStatsCardWidget(
                        title: 'Total Notes',
                        value: statsData['totalNotes'].toString(),
                        icon: 'note',
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      SizedBox(width: 3.w),
                      QuickStatsCardWidget(
                        title: 'Recent Activity',
                        value: statsData['recentActivity'].toString(),
                        icon: 'trending_up',
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                      SizedBox(width: 3.w),
                      QuickStatsCardWidget(
                        title: 'Storage Used',
                        value: statsData['storageUsed'],
                        icon: 'storage',
                        color: const Color(0xFF34C759),
                        progress: statsData['storagePercentage'],
                      ),
                    ],
                  ),
                ),

                // Recent Notes Header
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Recent Notes',
                        style:
                            Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      TextButton(
                        onPressed: () =>
                            Navigator.pushNamed(context, '/notes-list'),
                        child: Text('View All'),
                      ),
                    ],
                  ),
                ),

                // Recent Notes List
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: recentNotes.isEmpty
                        ? _buildEmptyState()
                        : ListView.builder(
                            controller: _scrollController,
                            padding: EdgeInsets.symmetric(horizontal: 4.w),
                            itemCount: recentNotes.length,
                            itemBuilder: (context, index) {
                              final note = recentNotes[index];
                              return Dismissible(
                                key: Key(note['id'].toString()),
                                background: _buildSwipeBackground(isLeft: true),
                                secondaryBackground:
                                    _buildSwipeBackground(isLeft: false),
                                onDismissed: (direction) {
                                  if (direction ==
                                      DismissDirection.startToEnd) {
                                    // Archive action
                                  } else {
                                    // Delete action
                                  }
                                },
                                child: RecentNoteCardWidget(
                                  note: note,
                                  onTap: () => _onNoteCardTap(note),
                                  onLongPress: () => _onNoteCardLongPress(note),
                                ),
                              );
                            },
                          ),
                  ),
                ),
              ],
            ),

            // Quick Action Menu
            if (_showQuickActionMenu)
              QuickActionMenuWidget(
                onActionSelected: _onQuickActionSelected,
                onClose: _toggleQuickActionMenu,
              ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          border: Border(
            top: BorderSide(
              color:
                  Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
              width: 0.5,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onBottomNavTap,
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: Theme.of(context).colorScheme.primary,
          unselectedItemColor: Theme.of(context).colorScheme.onSurfaceVariant,
          items: [
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'dashboard',
                color: _selectedIndex == 0
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'note',
                color: _selectedIndex == 1
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Notes',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'calculate',
                color: _selectedIndex == 2
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Calculator',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'settings',
                color: _selectedIndex == 3
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                size: 24,
              ),
              label: 'Settings',
            ),
          ],
        ),
      ),
      floatingActionButton: ScaleTransition(
        scale: _fabAnimation,
        child: FloatingActionButton(
          onPressed: _toggleQuickActionMenu,
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Theme.of(context).colorScheme.onPrimary,
          elevation: 6,
          child: AnimatedRotation(
            turns: _showQuickActionMenu ? 0.125 : 0,
            duration: const Duration(milliseconds: 200),
            child: CustomIconWidget(
              iconName: _showQuickActionMenu ? 'close' : 'add',
              color: Theme.of(context).colorScheme.onPrimary,
              size: 24,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'note_add',
            color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
            size: 80,
          ),
          SizedBox(height: 2.h),
          Text(
            'Create Your First Note',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Tap the + button to get started',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwipeBackground({required bool isLeft}) {
    return Container(
      alignment: isLeft ? Alignment.centerLeft : Alignment.centerRight,
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      color: isLeft
          ? Theme.of(context).colorScheme.secondary.withValues(alpha: 0.1)
          : Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
      child: CustomIconWidget(
        iconName: isLeft ? 'archive' : 'delete',
        color: isLeft
            ? Theme.of(context).colorScheme.secondary
            : Theme.of(context).colorScheme.error,
        size: 24,
      ),
    );
  }
}
