import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class AccumulationTrackingWidget extends StatelessWidget {
  final List<Map<String, dynamic>> calculationHistory;
  final Function(String) onDeleteCalculation;
  final VoidCallback onClearAll;
  final String Function(double) formatNumber;

  const AccumulationTrackingWidget({
    super.key,
    required this.calculationHistory,
    required this.onDeleteCalculation,
    required this.onClearAll,
    required this.formatNumber,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'history',
                      color: Theme.of(context).colorScheme.primary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Calculation History',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ],
                ),
                if (calculationHistory.isNotEmpty)
                  TextButton(
                    onPressed: onClearAll,
                    child: Text(
                      'Clear All',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                        fontSize: 12.sp,
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 2.h),
            calculationHistory.isEmpty
                ? _buildEmptyState(context)
                : _buildHistoryList(context),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(6.w),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: 'history_toggle_off',
            color: Theme.of(context).colorScheme.onSurfaceVariant,
            size: 48,
          ),
          SizedBox(height: 2.h),
          Text(
            'No calculations yet',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Your saved calculations will appear here',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryList(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: 40.h,
      ),
      child: RefreshIndicator(
        onRefresh: () async {
          // Simulate refresh delay
          await Future.delayed(Duration(milliseconds: 500));
        },
        child: ListView.separated(
          shrinkWrap: true,
          itemCount: calculationHistory.length,
          separatorBuilder: (context, index) => SizedBox(height: 1.h),
          itemBuilder: (context, index) {
            final calculation = calculationHistory[index];
            return _buildHistoryItem(context, calculation, index);
          },
        ),
      ),
    );
  }

  Widget _buildHistoryItem(
      BuildContext context, Map<String, dynamic> calculation, int index) {
    final DateTime timestamp = calculation['timestamp'] as DateTime;
    final String timeAgo = _getTimeAgo(timestamp);

    return Dismissible(
      key: Key(calculation['id'].toString()),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: EdgeInsets.only(right: 4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.error,
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomIconWidget(
          iconName: 'delete',
          color: Colors.white,
          size: 24,
        ),
      ),
      onDismissed: (direction) {
        onDeleteCalculation(calculation['id'].toString());
      },
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
            width: 0.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Calculation #${calculationHistory.length - index}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  timeAgo,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Row(
              children: [
                Expanded(
                  child: _buildHistoryMetric(
                    context: context,
                    label: 'Loss',
                    value:
                        '${calculation['currency']}${formatNumber(calculation['lossAmount'])}',
                    icon: 'trending_down',
                    color: Theme.of(context).colorScheme.error,
                  ),
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: _buildHistoryMetric(
                    context: context,
                    label: 'Capital',
                    value:
                        '${calculation['currency']}${formatNumber(calculation['currentCapital'])}',
                    icon: 'account_balance_wallet',
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Row(
              children: [
                Expanded(
                  child: _buildHistoryMetric(
                    context: context,
                    label: 'Required Profit',
                    value:
                        '${calculation['requiredProfitPercentage'].toStringAsFixed(1)}%',
                    icon: 'trending_up',
                    color: Colors.green,
                  ),
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: _buildHistoryMetric(
                    context: context,
                    label: 'Risk Ratio',
                    value:
                        '${calculation['riskManagementRatio'].toStringAsFixed(1)}%',
                    icon: 'security',
                    color: Colors.orange,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryMetric({
    required BuildContext context,
    required String label,
    required String value,
    required String icon,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: icon,
                color: color,
                size: 12,
              ),
              SizedBox(width: 1.w),
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: color,
                      fontSize: 10.sp,
                    ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Text(
            value,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: color,
                ),
          ),
        ],
      ),
    );
  }

  String _getTimeAgo(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}
