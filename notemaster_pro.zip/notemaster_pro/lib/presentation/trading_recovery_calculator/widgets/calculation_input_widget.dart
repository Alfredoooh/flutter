import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CalculationInputWidget extends StatelessWidget {
  final TextEditingController lossAmountController;
  final TextEditingController currentCapitalController;
  final TextEditingController targetRecoveryController;
  final FocusNode lossAmountFocus;
  final FocusNode currentCapitalFocus;
  final FocusNode targetRecoveryFocus;
  final String selectedCurrency;
  final String errorMessage;
  final bool isCalculating;

  const CalculationInputWidget({
    super.key,
    required this.lossAmountController,
    required this.currentCapitalController,
    required this.targetRecoveryController,
    required this.lossAmountFocus,
    required this.currentCapitalFocus,
    required this.targetRecoveryFocus,
    required this.selectedCurrency,
    required this.errorMessage,
    required this.isCalculating,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'calculate',
                  color: Theme.of(context).colorScheme.primary,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Input Values',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                if (isCalculating) ...[
                  SizedBox(width: 2.w),
                  SizedBox(
                    width: 4.w,
                    height: 4.w,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  ),
                ],
              ],
            ),

            SizedBox(height: 3.h),

            // Loss Amount Input
            _buildInputField(
              context: context,
              label: 'Loss Amount',
              controller: lossAmountController,
              focusNode: lossAmountFocus,
              nextFocusNode: currentCapitalFocus,
              prefix: selectedCurrency,
              hint: '0.00',
              icon: 'trending_down',
            ),

            SizedBox(height: 2.h),

            // Current Capital Input
            _buildInputField(
              context: context,
              label: 'Current Capital',
              controller: currentCapitalController,
              focusNode: currentCapitalFocus,
              nextFocusNode: targetRecoveryFocus,
              prefix: selectedCurrency,
              hint: '0.00',
              icon: 'account_balance_wallet',
            ),

            SizedBox(height: 2.h),

            // Target Recovery Input
            _buildInputField(
              context: context,
              label: 'Target Recovery',
              controller: targetRecoveryController,
              focusNode: targetRecoveryFocus,
              suffix: '%',
              hint: '100',
              icon: 'target',
              isLastField: true,
            ),

            if (errorMessage.isNotEmpty) ...[
              SizedBox(height: 2.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .error
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Theme.of(context)
                        .colorScheme
                        .error
                        .withValues(alpha: 0.3),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'warning',
                      color: Theme.of(context).colorScheme.error,
                      size: 16,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        errorMessage,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context).colorScheme.error,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required BuildContext context,
    required String label,
    required TextEditingController controller,
    required FocusNode focusNode,
    FocusNode? nextFocusNode,
    String? prefix,
    String? suffix,
    required String hint,
    required String icon,
    bool isLastField = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.onSurface,
              ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: controller,
          focusNode: focusNode,
          keyboardType: TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
          ],
          textInputAction:
              isLastField ? TextInputAction.done : TextInputAction.next,
          onFieldSubmitted: (_) {
            if (!isLastField && nextFocusNode != null) {
              FocusScope.of(context).requestFocus(nextFocusNode);
            } else {
              focusNode.unfocus();
            }
          },
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: icon,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                size: 20,
              ),
            ),
            prefixText: prefix,
            suffixText: suffix,
            prefixStyle: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.primary,
                ),
            suffixStyle: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w500,
              ),
        ),
      ],
    );
  }
}
