import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CalculationResultsWidget extends StatelessWidget {
  final double requiredProfitPercentage;
  final double recommendedPositionSize;
  final double riskManagementRatio;
  final String selectedCurrency;
  final String Function(double) formatNumber;

  const CalculationResultsWidget({
    super.key,
    required this.requiredProfitPercentage,
    required this.recommendedPositionSize,
    required this.riskManagementRatio,
    required this.selectedCurrency,
    required this.formatNumber,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'analytics',
                  color: Theme.of(context).colorScheme.primary,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Calculation Results',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Required Profit Percentage
            _buildResultCard(
              context: context,
              title: 'Required Profit',
              value: '${requiredProfitPercentage.toStringAsFixed(2)}%',
              subtitle: 'Profit needed to recover loss',
              icon: 'trending_up',
              color: _getColorForPercentage(context, requiredProfitPercentage),
            ),

            SizedBox(height: 2.h),

            // Recommended Position Size
            _buildResultCard(
              context: context,
              title: 'Recommended Position',
              value:
                  '$selectedCurrency${formatNumber(recommendedPositionSize)}',
              subtitle: 'Suggested position size',
              icon: 'pie_chart',
              color: Theme.of(context).colorScheme.secondary,
            ),

            SizedBox(height: 2.h),

            // Risk Management Ratio
            _buildResultCard(
              context: context,
              title: 'Risk Ratio',
              value: '${riskManagementRatio.toStringAsFixed(2)}%',
              subtitle: 'Loss to capital ratio',
              icon: 'security',
              color: _getColorForRisk(context, riskManagementRatio),
            ),

            if (requiredProfitPercentage > 0) ...[
              SizedBox(height: 3.h),
              _buildRiskAssessment(context),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard({
    required BuildContext context,
    required String title,
    required String value,
    required String subtitle,
    required String icon,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 0.5,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: icon,
                color: color,
                size: 24,
              ),
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  value,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: color,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRiskAssessment(BuildContext context) {
    String riskLevel;
    Color riskColor;
    String riskDescription;
    String riskIcon;

    if (riskManagementRatio <= 2) {
      riskLevel = 'Low Risk';
      riskColor = Colors.green;
      riskDescription = 'Conservative risk level. Good for steady growth.';
      riskIcon = 'check_circle';
    } else if (riskManagementRatio <= 5) {
      riskLevel = 'Moderate Risk';
      riskColor = Colors.orange;
      riskDescription = 'Balanced risk level. Monitor positions carefully.';
      riskIcon = 'warning';
    } else {
      riskLevel = 'High Risk';
      riskColor = Colors.red;
      riskDescription = 'High risk level. Consider reducing position size.';
      riskIcon = 'error';
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: riskColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: riskColor.withValues(alpha: 0.3),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: riskIcon,
                color: riskColor,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Risk Assessment',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: riskColor,
                    ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            riskLevel,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: riskColor,
                ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            riskDescription,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  Color _getColorForPercentage(BuildContext context, double percentage) {
    if (percentage <= 10) {
      return Colors.green;
    } else if (percentage <= 25) {
      return Colors.orange;
    } else if (percentage <= 50) {
      return Colors.deepOrange;
    } else {
      return Colors.red;
    }
  }

  Color _getColorForRisk(BuildContext context, double riskRatio) {
    if (riskRatio <= 2) {
      return Colors.green;
    } else if (riskRatio <= 5) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }
}
