import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/accumulation_tracking_widget.dart';
import './widgets/calculation_input_widget.dart';
import './widgets/calculation_results_widget.dart';
import './widgets/currency_selector_widget.dart';

class TradingRecoveryCalculator extends StatefulWidget {
  const TradingRecoveryCalculator({super.key});

  @override
  State<TradingRecoveryCalculator> createState() =>
      _TradingRecoveryCalculatorState();
}

class _TradingRecoveryCalculatorState extends State<TradingRecoveryCalculator>
    with TickerProviderStateMixin {
  final TextEditingController _lossAmountController = TextEditingController();
  final TextEditingController _currentCapitalController =
      TextEditingController();
  final TextEditingController _targetRecoveryController =
      TextEditingController();

  final FocusNode _lossAmountFocus = FocusNode();
  final FocusNode _currentCapitalFocus = FocusNode();
  final FocusNode _targetRecoveryFocus = FocusNode();

  String _selectedCurrency = '\$';
  double _lossAmount = 0.0;
  double _currentCapital = 0.0;
  double _targetRecovery = 100.0;

  double _requiredProfitPercentage = 0.0;
  double _recommendedPositionSize = 0.0;
  double _riskManagementRatio = 0.0;

  List<Map<String, dynamic>> _calculationHistory = [];
  bool _isCalculating = false;
  String _errorMessage = '';

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  final List<Map<String, String>> _currencies = [
    {'symbol': '\$', 'name': 'USD', 'code': 'USD'},
    {'symbol': '₹', 'name': 'INR', 'code': 'INR'},
    {'symbol': '€', 'name': 'EUR', 'code': 'EUR'},
    {'symbol': '£', 'name': 'GBP', 'code': 'GBP'},
    {'symbol': '¥', 'name': 'JPY', 'code': 'JPY'},
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _lossAmountController.addListener(_onInputChanged);
    _currentCapitalController.addListener(_onInputChanged);
    _targetRecoveryController.addListener(_onInputChanged);

    _targetRecoveryController.text = '100';
    _loadCalculationHistory();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _lossAmountController.dispose();
    _currentCapitalController.dispose();
    _targetRecoveryController.dispose();
    _lossAmountFocus.dispose();
    _currentCapitalFocus.dispose();
    _targetRecoveryFocus.dispose();
    super.dispose();
  }

  void _onInputChanged() {
    setState(() {
      _lossAmount = double.tryParse(_lossAmountController.text) ?? 0.0;
      _currentCapital = double.tryParse(_currentCapitalController.text) ?? 0.0;
      _targetRecovery =
          double.tryParse(_targetRecoveryController.text) ?? 100.0;
      _errorMessage = '';
    });
    _calculateRecovery();
  }

  void _calculateRecovery() {
    if (_lossAmount <= 0 || _currentCapital <= 0) {
      setState(() {
        _requiredProfitPercentage = 0.0;
        _recommendedPositionSize = 0.0;
        _riskManagementRatio = 0.0;
        _errorMessage = '';
      });
      return;
    }

    try {
      setState(() {
        _isCalculating = true;
        _errorMessage = '';
      });

      // Calculate required profit percentage
      final targetAmount = _lossAmount * (_targetRecovery / 100);
      _requiredProfitPercentage = (targetAmount / _currentCapital) * 100;

      // Calculate recommended position size (Kelly Criterion approximation)
      final winRate = 0.6; // Assumed 60% win rate
      final avgWin = targetAmount * 1.5;
      final avgLoss = targetAmount * 0.5;
      _recommendedPositionSize =
          ((winRate * avgWin - (1 - winRate) * avgLoss) / avgWin) *
              _currentCapital;

      // Calculate risk management ratio
      _riskManagementRatio = (_lossAmount / _currentCapital) * 100;

      // Validate calculations
      if (_requiredProfitPercentage.isInfinite ||
          _requiredProfitPercentage.isNaN) {
        throw Exception(
            'Invalid calculation: Division by zero or infinite result');
      }

      if (_requiredProfitPercentage > 1000) {
        setState(() {
          _errorMessage =
              'Warning: Required profit percentage is extremely high (${_requiredProfitPercentage.toStringAsFixed(1)}%)';
        });
      }

      _animationController.forward();

      // Haptic feedback for successful calculation
      HapticFeedback.lightImpact();
    } catch (e) {
      setState(() {
        _errorMessage = 'Calculation error: ${e.toString()}';
        _requiredProfitPercentage = 0.0;
        _recommendedPositionSize = 0.0;
        _riskManagementRatio = 0.0;
      });

      // Error vibration
      HapticFeedback.heavyImpact();
    } finally {
      setState(() {
        _isCalculating = false;
      });
    }
  }

  void _saveCalculation() {
    if (_lossAmount <= 0 || _currentCapital <= 0) return;

    final calculation = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'timestamp': DateTime.now(),
      'currency': _selectedCurrency,
      'lossAmount': _lossAmount,
      'currentCapital': _currentCapital,
      'targetRecovery': _targetRecovery,
      'requiredProfitPercentage': _requiredProfitPercentage,
      'recommendedPositionSize': _recommendedPositionSize,
      'riskManagementRatio': _riskManagementRatio,
    };

    setState(() {
      _calculationHistory.insert(0, calculation);
      if (_calculationHistory.length > 50) {
        _calculationHistory.removeLast();
      }
    });

    HapticFeedback.mediumImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Calculation saved successfully'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _shareCalculation() {
    if (_lossAmount <= 0 || _currentCapital <= 0) return;

    final shareText = '''
Trading Recovery Calculator Results
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Input Values:
• Loss Amount: $_selectedCurrency${_formatNumber(_lossAmount)}
• Current Capital: $_selectedCurrency${_formatNumber(_currentCapital)}
• Target Recovery: ${_targetRecovery.toStringAsFixed(1)}%

Calculated Results:
• Required Profit: ${_requiredProfitPercentage.toStringAsFixed(2)}%
• Recommended Position: $_selectedCurrency${_formatNumber(_recommendedPositionSize)}
• Risk Ratio: ${_riskManagementRatio.toStringAsFixed(2)}%

Generated by NoteMaster Pro
${DateTime.now().toString().split('.')[0]}
    ''';

    // Platform share functionality would be implemented here
    // For now, copy to clipboard
    Clipboard.setData(ClipboardData(text: shareText));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Results copied to clipboard'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _loadCalculationHistory() {
    // Mock calculation history data
    _calculationHistory = [
      {
        'id': '1',
        'timestamp': DateTime.now().subtract(Duration(hours: 2)),
        'currency': '\$',
        'lossAmount': 500.0,
        'currentCapital': 2000.0,
        'targetRecovery': 100.0,
        'requiredProfitPercentage': 25.0,
        'recommendedPositionSize': 800.0,
        'riskManagementRatio': 25.0,
      },
      {
        'id': '2',
        'timestamp': DateTime.now().subtract(Duration(days: 1)),
        'currency': '₹',
        'lossAmount': 10000.0,
        'currentCapital': 50000.0,
        'targetRecovery': 100.0,
        'requiredProfitPercentage': 20.0,
        'recommendedPositionSize': 20000.0,
        'riskManagementRatio': 20.0,
      },
    ];
  }

  void _deleteCalculation(String id) {
    setState(() {
      _calculationHistory.removeWhere((calc) => calc['id'] == id);
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Calculation deleted'),
        duration: Duration(seconds: 2),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            // Undo functionality would restore the deleted item
          },
        ),
      ),
    );
  }

  void _clearAllCalculations() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Clear All Calculations'),
          content: Text(
              'Are you sure you want to delete all saved calculations? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _calculationHistory.clear();
                });
                Navigator.of(context).pop();
                HapticFeedback.mediumImpact();
              },
              child: Text('Clear All'),
            ),
          ],
        );
      },
    );
  }

  String _formatNumber(double number) {
    if (number >= 1000000) {
      return '${(number / 1000000).toStringAsFixed(2)}M';
    } else if (number >= 1000) {
      return '${(number / 1000).toStringAsFixed(2)}K';
    } else {
      return number.toStringAsFixed(2);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Trading Recovery Calculator'),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: CustomIconWidget(
            iconName: 'arrow_back_ios',
            color: Theme.of(context).appBarTheme.foregroundColor!,
            size: 20,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _shareCalculation,
            icon: CustomIconWidget(
              iconName: 'share',
              color: Theme.of(context).appBarTheme.foregroundColor!,
              size: 20,
            ),
          ),
          IconButton(
            onPressed: _saveCalculation,
            icon: CustomIconWidget(
              iconName: 'bookmark',
              color: Theme.of(context).appBarTheme.foregroundColor!,
              size: 20,
            ),
          ),
        ],
      ),
      body: OrientationBuilder(
        builder: (context, orientation) {
          return orientation == Orientation.portrait
              ? _buildPortraitLayout()
              : _buildLandscapeLayout();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _lossAmountController.clear();
          _currentCapitalController.clear();
          _targetRecoveryController.text = '100';
          setState(() {
            _errorMessage = '';
            _requiredProfitPercentage = 0.0;
            _recommendedPositionSize = 0.0;
            _riskManagementRatio = 0.0;
          });
          _animationController.reset();
        },
        child: CustomIconWidget(
          iconName: 'refresh',
          color: Theme.of(context).floatingActionButtonTheme.foregroundColor!,
          size: 24,
        ),
      ),
    );
  }

  Widget _buildPortraitLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Currency Selector
          CurrencySelectorWidget(
            currencies: _currencies,
            selectedCurrency: _selectedCurrency,
            onCurrencyChanged: (currency) {
              setState(() {
                _selectedCurrency = currency;
              });
              _calculateRecovery();
            },
          ),

          SizedBox(height: 3.h),

          // Input Section
          CalculationInputWidget(
            lossAmountController: _lossAmountController,
            currentCapitalController: _currentCapitalController,
            targetRecoveryController: _targetRecoveryController,
            lossAmountFocus: _lossAmountFocus,
            currentCapitalFocus: _currentCapitalFocus,
            targetRecoveryFocus: _targetRecoveryFocus,
            selectedCurrency: _selectedCurrency,
            errorMessage: _errorMessage,
            isCalculating: _isCalculating,
          ),

          SizedBox(height: 3.h),

          // Results Section
          FadeTransition(
            opacity: _fadeAnimation,
            child: CalculationResultsWidget(
              requiredProfitPercentage: _requiredProfitPercentage,
              recommendedPositionSize: _recommendedPositionSize,
              riskManagementRatio: _riskManagementRatio,
              selectedCurrency: _selectedCurrency,
              formatNumber: _formatNumber,
            ),
          ),

          SizedBox(height: 3.h),

          // History Section
          AccumulationTrackingWidget(
            calculationHistory: _calculationHistory,
            onDeleteCalculation: _deleteCalculation,
            onClearAll: _clearAllCalculations,
            formatNumber: _formatNumber,
          ),
        ],
      ),
    );
  }

  Widget _buildLandscapeLayout() {
    return Padding(
      padding: EdgeInsets.all(2.w),
      child: Row(
        children: [
          // Left side - Input
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CurrencySelectorWidget(
                    currencies: _currencies,
                    selectedCurrency: _selectedCurrency,
                    onCurrencyChanged: (currency) {
                      setState(() {
                        _selectedCurrency = currency;
                      });
                      _calculateRecovery();
                    },
                  ),
                  SizedBox(height: 2.h),
                  CalculationInputWidget(
                    lossAmountController: _lossAmountController,
                    currentCapitalController: _currentCapitalController,
                    targetRecoveryController: _targetRecoveryController,
                    lossAmountFocus: _lossAmountFocus,
                    currentCapitalFocus: _currentCapitalFocus,
                    targetRecoveryFocus: _targetRecoveryFocus,
                    selectedCurrency: _selectedCurrency,
                    errorMessage: _errorMessage,
                    isCalculating: _isCalculating,
                  ),
                ],
              ),
            ),
          ),

          SizedBox(width: 2.w),

          // Right side - Results and History
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: CalculationResultsWidget(
                      requiredProfitPercentage: _requiredProfitPercentage,
                      recommendedPositionSize: _recommendedPositionSize,
                      riskManagementRatio: _riskManagementRatio,
                      selectedCurrency: _selectedCurrency,
                      formatNumber: _formatNumber,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  AccumulationTrackingWidget(
                    calculationHistory: _calculationHistory,
                    onDeleteCalculation: _deleteCalculation,
                    onClearAll: _clearAllCalculations,
                    formatNumber: _formatNumber,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
