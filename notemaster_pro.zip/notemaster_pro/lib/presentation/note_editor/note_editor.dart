import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/find_replace_widget.dart';
import './widgets/formatting_toolbar_widget.dart';

class NoteEditor extends StatefulWidget {
  const NoteEditor({super.key});

  @override
  State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> with TickerProviderStateMixin {
  // Controllers and Focus Nodes
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  late FocusNode _titleFocusNode;
  late FocusNode _contentFocusNode;
  late AnimationController _toolbarAnimationController;
  late AnimationController _findReplaceAnimationController;

  // State Variables
  bool _isEditing = false;
  bool _hasUnsavedChanges = false;
  bool _showFormattingToolbar = false;
  bool _showFindReplace = false;
  bool _isCodeMode = false;
  bool _showLineNumbers = true;
  double _textScale = 1.0;
  String _saveStatus = 'Saved';

  // Mock note data
  final Map<String, dynamic> _currentNote = {
    "id": 1,
    "title": "My Important Note",
    "content": """# Welcome to NoteMaster Pro

This is a comprehensive note-taking application with advanced text editing capabilities.

## Features:
- Rich text formatting
- Markdown support
- Find and replace
- Voice-to-text
- Auto-save functionality

### Code Example:
void main() {
  print('Hello, NoteMaster Pro!');
}

**Bold text** and *italic text* are supported.

> This is a blockquote with important information.

1. First item
2. Second item
3. Third item

- Bullet point one
- Bullet point two
- Bullet point three

[Link to documentation](https://example.com)

---

*Last edited: ${DateTime.now().toString().split('.')[0]}*""",
    "lastModified": DateTime.now(),
    "tags": ["important", "work", "notes"],
    "wordCount": 0,
    "characterCount": 0,
  };

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _setupAnimations();
    _loadNoteContent();
    _startAutoSave();
  }

  void _initializeControllers() {
    _titleController = TextEditingController();
    _contentController = TextEditingController();
    _titleFocusNode = FocusNode();
    _contentFocusNode = FocusNode();

    _titleController.addListener(_onTitleChanged);
    _contentController.addListener(_onContentChanged);
    _contentFocusNode.addListener(_onContentFocusChanged);
  }

  void _setupAnimations() {
    _toolbarAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _findReplaceAnimationController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );
  }

  void _loadNoteContent() {
    _titleController.text = _currentNote["title"] ?? "";
    _contentController.text = _currentNote["content"] ?? "";
    _updateWordCount();
  }

  void _startAutoSave() {
    // Auto-save every 30 seconds
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted && _hasUnsavedChanges) {
        _saveNote();
        _startAutoSave();
      }
    });
  }

  void _onTitleChanged() {
    if (!_hasUnsavedChanges) {
      setState(() {
        _hasUnsavedChanges = true;
        _saveStatus = 'Unsaved';
      });
    }
  }

  void _onContentChanged() {
    if (!_hasUnsavedChanges) {
      setState(() {
        _hasUnsavedChanges = true;
        _saveStatus = 'Unsaved';
      });
    }
    _updateWordCount();
  }

  void _onContentFocusChanged() {
    setState(() {
      _isEditing = _contentFocusNode.hasFocus;
      if (_isEditing) {
        _showFormattingToolbar = true;
        _toolbarAnimationController.forward();
      } else {
        _showFormattingToolbar = false;
        _toolbarAnimationController.reverse();
      }
    });
  }

  void _updateWordCount() {
    final text = _contentController.text;
    final words =
        text.trim().isEmpty ? 0 : text.trim().split(RegExp(r'\s+')).length;
    final characters = text.length;

    setState(() {
      _currentNote["wordCount"] = words;
      _currentNote["characterCount"] = characters;
    });
  }

  void _saveNote() {
    setState(() {
      _hasUnsavedChanges = false;
      _saveStatus = 'Saving...';
    });

    // Simulate save operation
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _saveStatus = 'Saved';
          _currentNote["title"] = _titleController.text;
          _currentNote["content"] = _contentController.text;
          _currentNote["lastModified"] = DateTime.now();
        });

        // Show haptic feedback
        HapticFeedback.lightImpact();
      }
    });
  }

  void _toggleFindReplace() {
    setState(() {
      _showFindReplace = !_showFindReplace;
      if (_showFindReplace) {
        _findReplaceAnimationController.forward();
      } else {
        _findReplaceAnimationController.reverse();
      }
    });
  }

  void _toggleCodeMode() {
    setState(() {
      _isCodeMode = !_isCodeMode;
      _showLineNumbers = _isCodeMode;
    });
    HapticFeedback.selectionClick();
  }

  void _shareNote() {
    // Implement share functionality
    HapticFeedback.mediumImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Note shared successfully'),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _exportNote() {
    // Implement export functionality
    HapticFeedback.mediumImpact();
    _showExportOptions();
  }

  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 1.h),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                children: [
                  Text(
                    'Export Options',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 2.h),
                  _buildExportOption('PDF Document', 'picture_as_pdf'),
                  _buildExportOption('Plain Text', 'text_snippet'),
                  _buildExportOption('Markdown', 'code'),
                  _buildExportOption('Share Link', 'share'),
                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExportOption(String title, String iconName) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: Theme.of(context).colorScheme.primary,
        size: 24,
      ),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        HapticFeedback.selectionClick();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Exported as $title'),
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      },
    );
  }

  void _showSettingsMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 1.h),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                children: [
                  Text(
                    'Editor Settings',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 2.h),
                  SwitchListTile(
                    title: Text('Code Mode'),
                    subtitle: Text('Enable syntax highlighting'),
                    value: _isCodeMode,
                    onChanged: (value) {
                      Navigator.pop(context);
                      _toggleCodeMode();
                    },
                  ),
                  SwitchListTile(
                    title: Text('Line Numbers'),
                    subtitle: Text('Show line numbers'),
                    value: _showLineNumbers,
                    onChanged: (value) {
                      setState(() {
                        _showLineNumbers = value;
                      });
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    leading: CustomIconWidget(
                      iconName: 'text_fields',
                      color: Theme.of(context).colorScheme.primary,
                      size: 24,
                    ),
                    title: Text('Text Size'),
                    subtitle: Text('${(_textScale * 100).round()}%'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () {
                            setState(() {
                              _textScale = (_textScale - 0.1).clamp(0.5, 2.0);
                            });
                          },
                          icon: CustomIconWidget(
                            iconName: 'remove',
                            color: Theme.of(context).colorScheme.primary,
                            size: 20,
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            setState(() {
                              _textScale = (_textScale + 0.1).clamp(0.5, 2.0);
                            });
                          },
                          icon: CustomIconWidget(
                            iconName: 'add',
                            color: Theme.of(context).colorScheme.primary,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    _titleFocusNode.dispose();
    _contentFocusNode.dispose();
    _toolbarAnimationController.dispose();
    _findReplaceAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Top Navigation Bar
            _buildTopNavigationBar(),

            // Find/Replace Overlay
            if (_showFindReplace)
              SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, -1),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: _findReplaceAnimationController,
                  curve: Curves.easeInOut,
                )),
                child: FindReplaceWidget(
                  controller: _contentController,
                  onClose: _toggleFindReplace,
                ),
              ),

            // Main Editor Area
            Expanded(
              child: _buildEditorArea(),
            ),

            // Bottom Toolbar
            if (_showFormattingToolbar)
              SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 1),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: _toolbarAnimationController,
                  curve: Curves.easeInOut,
                )),
                child: FormattingToolbarWidget(
                  controller: _contentController,
                  onFormatApplied: () {
                    HapticFeedback.selectionClick();
                    _onContentChanged();
                  },
                ),
              ),

            // Status Bar
            _buildStatusBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildTopNavigationBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        children: [
          // Back Button
          IconButton(
            onPressed: () {
              if (_hasUnsavedChanges) {
                _showUnsavedChangesDialog();
              } else {
                Navigator.pop(context);
              }
            },
            icon: CustomIconWidget(
              iconName: 'arrow_back_ios',
              color: Theme.of(context).colorScheme.primary,
              size: 24,
            ),
          ),

          // Title Field
          Expanded(
            child: TextField(
              controller: _titleController,
              focusNode: _titleFocusNode,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              decoration: InputDecoration(
                hintText: 'Note Title',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 2.w),
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _contentFocusNode.requestFocus(),
            ),
          ),

          // Action Buttons
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Save Status
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: _saveStatus == 'Saved'
                      ? Theme.of(context)
                          .colorScheme
                          .primary
                          .withValues(alpha: 0.1)
                      : Theme.of(context)
                          .colorScheme
                          .error
                          .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _saveStatus,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: _saveStatus == 'Saved'
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.error,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ),

              SizedBox(width: 2.w),

              // More Options
              PopupMenuButton<String>(
                onSelected: (value) {
                  switch (value) {
                    case 'share':
                      _shareNote();
                      break;
                    case 'export':
                      _exportNote();
                      break;
                    case 'find':
                      _toggleFindReplace();
                      break;
                    case 'settings':
                      _showSettingsMenu();
                      break;
                  }
                },
                itemBuilder: (context) => [
                  PopupMenuItem(
                    value: 'share',
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'share',
                          color: Theme.of(context).colorScheme.onSurface,
                          size: 20,
                        ),
                        SizedBox(width: 3.w),
                        Text('Share'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'export',
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'file_download',
                          color: Theme.of(context).colorScheme.onSurface,
                          size: 20,
                        ),
                        SizedBox(width: 3.w),
                        Text('Export'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'find',
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'search',
                          color: Theme.of(context).colorScheme.onSurface,
                          size: 20,
                        ),
                        SizedBox(width: 3.w),
                        Text('Find & Replace'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'settings',
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'settings',
                          color: Theme.of(context).colorScheme.onSurface,
                          size: 20,
                        ),
                        SizedBox(width: 3.w),
                        Text('Settings'),
                      ],
                    ),
                  ),
                ],
                child: CustomIconWidget(
                  iconName: 'more_vert',
                  color: Theme.of(context).colorScheme.onSurface,
                  size: 24,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEditorArea() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Line Numbers (if enabled)
          if (_showLineNumbers && _isCodeMode)
            Container(
              width: 12.w,
              padding: EdgeInsets.only(top: 2.h, right: 2.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: _buildLineNumbers(),
              ),
            ),

          // Main Text Editor
          Expanded(
            child: TextField(
              controller: _contentController,
              focusNode: _contentFocusNode,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    fontSize:
                        (Theme.of(context).textTheme.bodyLarge?.fontSize ??
                                16) *
                            _textScale,
                    fontFamily: _isCodeMode ? 'monospace' : null,
                    height: 1.5,
                  ),
              decoration: InputDecoration(
                hintText: 'Start writing your note...',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 2.h),
              ),
              maxLines: null,
              expands: true,
              textAlignVertical: TextAlignVertical.top,
              keyboardType: TextInputType.multiline,
              textInputAction: TextInputAction.newline,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildLineNumbers() {
    final lines = _contentController.text.split('\n').length;
    return List.generate(lines, (index) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 0.2.h),
        child: Text(
          '${index + 1}',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.outline,
                fontFamily: 'monospace',
              ),
        ),
      );
    });
  }

  Widget _buildStatusBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.8),
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Word Count
          Text(
            '${_currentNote["wordCount"]} words, ${_currentNote["characterCount"]} characters',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),

          // Voice Input Button
          IconButton(
            onPressed: _startVoiceInput,
            icon: CustomIconWidget(
              iconName: 'mic',
              color: Theme.of(context).colorScheme.primary,
              size: 20,
            ),
            tooltip: 'Voice to Text',
          ),
        ],
      ),
    );
  }

  void _startVoiceInput() {
    HapticFeedback.mediumImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'mic',
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text('Voice input started...'),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showUnsavedChangesDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Unsaved Changes'),
        content: Text(
            'You have unsaved changes. Do you want to save before leaving?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text('Discard'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              _saveNote();
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }
}
