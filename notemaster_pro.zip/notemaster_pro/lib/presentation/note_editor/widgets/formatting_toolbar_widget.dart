import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class FormattingToolbarWidget extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback? onFormatApplied;

  const FormattingToolbarWidget({
    super.key,
    required this.controller,
    this.onFormatApplied,
  });

  @override
  State<FormattingToolbarWidget> createState() =>
      _FormattingToolbarWidgetState();
}

class _FormattingToolbarWidgetState extends State<FormattingToolbarWidget> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _applyFormat(String prefix, String suffix, {String? placeholder}) {
    final selection = widget.controller.selection;
    final text = widget.controller.text;

    String selectedText = '';
    if (selection.isValid && !selection.isCollapsed) {
      selectedText = text.substring(selection.start, selection.end);
    } else if (placeholder != null) {
      selectedText = placeholder;
    }

    final formattedText = '$prefix$selectedText$suffix';
    final newText = text.replaceRange(
      selection.start,
      selection.end,
      formattedText,
    );

    widget.controller.text = newText;

    // Set cursor position
    final newCursorPos = selection.start + prefix.length + selectedText.length;
    widget.controller.selection = TextSelection.collapsed(offset: newCursorPos);

    widget.onFormatApplied?.call();
    HapticFeedback.selectionClick();
  }

  void _insertAtCursor(String text) {
    final selection = widget.controller.selection;
    final currentText = widget.controller.text;

    final newText = currentText.replaceRange(
      selection.start,
      selection.end,
      text,
    );

    widget.controller.text = newText;
    widget.controller.selection = TextSelection.collapsed(
      offset: selection.start + text.length,
    );

    widget.onFormatApplied?.call();
    HapticFeedback.selectionClick();
  }

  void _applyHeading(int level) {
    final selection = widget.controller.selection;
    final text = widget.controller.text;

    // Find the start of the current line
    int lineStart = selection.start;
    while (lineStart > 0 && text[lineStart - 1] != '\n') {
      lineStart--;
    }

    // Find the end of the current line
    int lineEnd = selection.start;
    while (lineEnd < text.length && text[lineEnd] != '\n') {
      lineEnd++;
    }

    final currentLine = text.substring(lineStart, lineEnd);
    final headingPrefix = '${'#' * level} ';

    String newLine;
    if (currentLine.startsWith(RegExp(r'^#{1,6} '))) {
      // Replace existing heading
      newLine = currentLine.replaceFirst(RegExp(r'^#{1,6} '), headingPrefix);
    } else {
      // Add heading to existing line
      newLine = headingPrefix + currentLine;
    }

    final newText = text.replaceRange(lineStart, lineEnd, newLine);
    widget.controller.text = newText;

    // Maintain cursor position relative to line content
    final cursorOffset = selection.start - lineStart;
    final newCursorPos = lineStart + headingPrefix.length + cursorOffset;
    widget.controller.selection = TextSelection.collapsed(
      offset: newCursorPos.clamp(0, newText.length),
    );

    widget.onFormatApplied?.call();
    HapticFeedback.mediumImpact();
  }

  void _applyList(bool isOrdered) {
    final selection = widget.controller.selection;
    final text = widget.controller.text;

    // Find the start of the current line
    int lineStart = selection.start;
    while (lineStart > 0 && text[lineStart - 1] != '\n') {
      lineStart--;
    }

    // Find the end of the current line
    int lineEnd = selection.start;
    while (lineEnd < text.length && text[lineEnd] != '\n') {
      lineEnd++;
    }

    final currentLine = text.substring(lineStart, lineEnd);
    final listPrefix = isOrdered ? '1. ' : '- ';

    String newLine;
    if (currentLine.startsWith(RegExp(r'^(\d+\. |- )'))) {
      // Remove existing list formatting
      newLine = currentLine.replaceFirst(RegExp(r'^(\d+\. |- )'), '');
    } else {
      // Add list formatting
      newLine = listPrefix + currentLine;
    }

    final newText = text.replaceRange(lineStart, lineEnd, newLine);
    widget.controller.text = newText;

    widget.onFormatApplied?.call();
    HapticFeedback.mediumImpact();
  }

  void _indentText(bool indent) {
    final selection = widget.controller.selection;
    final text = widget.controller.text;

    // Find the start of the current line
    int lineStart = selection.start;
    while (lineStart > 0 && text[lineStart - 1] != '\n') {
      lineStart--;
    }

    // Find the end of the current line
    int lineEnd = selection.start;
    while (lineEnd < text.length && text[lineEnd] != '\n') {
      lineEnd++;
    }

    final currentLine = text.substring(lineStart, lineEnd);

    String newLine;
    if (indent) {
      newLine = '    $currentLine'; // Add 4 spaces
    } else {
      // Remove up to 4 spaces from the beginning
      newLine = currentLine.replaceFirst(RegExp(r'^    '), '');
      if (newLine == currentLine) {
        newLine = currentLine.replaceFirst(RegExp(r'^ {1,3}'), '');
      }
    }

    final newText = text.replaceRange(lineStart, lineEnd, newLine);
    widget.controller.text = newText;

    widget.onFormatApplied?.call();
    HapticFeedback.selectionClick();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 7.h,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: SingleChildScrollView(
        controller: _scrollController,
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 2.w),
        child: Row(
          children: [
            // Text Formatting
            _buildToolbarButton(
              context,
              'format_bold',
              'Bold',
              () => _applyFormat('**', '**', placeholder: 'bold text'),
            ),

            _buildToolbarButton(
              context,
              'format_italic',
              'Italic',
              () => _applyFormat('*', '*', placeholder: 'italic text'),
            ),

            _buildToolbarButton(
              context,
              'format_underlined',
              'Underline',
              () => _applyFormat('<u>', '</u>', placeholder: 'underlined text'),
            ),

            _buildToolbarButton(
              context,
              'strikethrough_s',
              'Strikethrough',
              () => _applyFormat('~~', '~~', placeholder: 'strikethrough text'),
            ),

            _buildDivider(context),

            // Headings
            _buildToolbarButton(
              context,
              'title',
              'Heading 1',
              () => _applyHeading(1),
            ),

            _buildToolbarButton(
              context,
              'title',
              'Heading 2',
              () => _applyHeading(2),
            ),

            _buildToolbarButton(
              context,
              'title',
              'Heading 3',
              () => _applyHeading(3),
            ),

            _buildDivider(context),

            // Lists
            _buildToolbarButton(
              context,
              'format_list_bulleted',
              'Bullet List',
              () => _applyList(false),
            ),

            _buildToolbarButton(
              context,
              'format_list_numbered',
              'Numbered List',
              () => _applyList(true),
            ),

            _buildDivider(context),

            // Indentation
            _buildToolbarButton(
              context,
              'format_indent_increase',
              'Indent',
              () => _indentText(true),
            ),

            _buildToolbarButton(
              context,
              'format_indent_decrease',
              'Unindent',
              () => _indentText(false),
            ),

            _buildDivider(context),

            // Special Insertions
            _buildToolbarButton(
              context,
              'code',
              'Inline Code',
              () => _applyFormat('`', '`', placeholder: 'code'),
            ),

            _buildToolbarButton(
              context,
              'code_blocks',
              'Code Block',
              () => _applyFormat('```\n', '\n```', placeholder: 'code block'),
            ),

            _buildToolbarButton(
              context,
              'format_quote',
              'Quote',
              () => _insertAtCursor('> '),
            ),

            _buildToolbarButton(
              context,
              'link',
              'Link',
              () => _applyFormat('[', '](url)', placeholder: 'link text'),
            ),

            _buildToolbarButton(
              context,
              'image',
              'Image',
              () => _insertAtCursor('![alt text](image_url)'),
            ),

            _buildToolbarButton(
              context,
              'table_chart',
              'Table',
              () => _insertAtCursor(
                  '\n| Column 1 | Column 2 |\n|----------|----------|\n| Cell 1   | Cell 2   |\n'),
            ),

            _buildDivider(context),

            // Special Characters
            _buildToolbarButton(
              context,
              'horizontal_rule',
              'Horizontal Rule',
              () => _insertAtCursor('\n---\n'),
            ),

            _buildToolbarButton(
              context,
              'check_box',
              'Checkbox',
              () => _insertAtCursor('- [ ] '),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolbarButton(
    BuildContext context,
    String iconName,
    String tooltip,
    VoidCallback onPressed,
  ) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 1.w),
      child: Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: EdgeInsets.all(2.w),
            child: CustomIconWidget(
              iconName: iconName,
              color: Theme.of(context).colorScheme.onSurface,
              size: 20,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDivider(BuildContext context) {
    return Container(
      width: 1,
      height: 4.h,
      margin: EdgeInsets.symmetric(horizontal: 2.w),
      color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
    );
  }
}
