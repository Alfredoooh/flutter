import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class FindReplaceWidget extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback onClose;

  const FindReplaceWidget({
    super.key,
    required this.controller,
    required this.onClose,
  });

  @override
  State<FindReplaceWidget> createState() => _FindReplaceWidgetState();
}

class _FindReplaceWidgetState extends State<FindReplaceWidget> {
  late TextEditingController _findController;
  late TextEditingController _replaceController;
  late FocusNode _findFocusNode;
  late FocusNode _replaceFocusNode;

  bool _isReplaceMode = false;
  bool _caseSensitive = false;
  bool _wholeWords = false;
  bool _useRegex = false;

  int _currentMatch = 0;
  int _totalMatches = 0;
  final List<TextSelection> _matches = [];

  @override
  void initState() {
    super.initState();
    _findController = TextEditingController();
    _replaceController = TextEditingController();
    _findFocusNode = FocusNode();
    _replaceFocusNode = FocusNode();

    _findController.addListener(_onFindTextChanged);

    // Auto-focus find field
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _findFocusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _findController.dispose();
    _replaceController.dispose();
    _findFocusNode.dispose();
    _replaceFocusNode.dispose();
    super.dispose();
  }

  void _onFindTextChanged() {
    _findMatches();
  }

  void _findMatches() {
    final findText = _findController.text;
    final content = widget.controller.text;

    if (findText.isEmpty) {
      setState(() {
        _matches.clear();
        _currentMatch = 0;
        _totalMatches = 0;
      });
      return;
    }

    _matches.clear();

    try {
      RegExp pattern;
      if (_useRegex) {
        pattern = RegExp(
          findText,
          caseSensitive: _caseSensitive,
        );
      } else {
        String escapedText = RegExp.escape(findText);
        if (_wholeWords) {
          escapedText = r'\b' + escapedText + r'\b';
        }
        pattern = RegExp(
          escapedText,
          caseSensitive: _caseSensitive,
        );
      }

      final matches = pattern.allMatches(content);
      for (final match in matches) {
        _matches.add(TextSelection(
          baseOffset: match.start,
          extentOffset: match.end,
        ));
      }

      setState(() {
        _totalMatches = _matches.length;
        _currentMatch = _totalMatches > 0 ? 1 : 0;
      });

      if (_matches.isNotEmpty) {
        _highlightCurrentMatch();
      }
    } catch (e) {
      // Invalid regex
      setState(() {
        _matches.clear();
        _currentMatch = 0;
        _totalMatches = 0;
      });
    }
  }

  void _highlightCurrentMatch() {
    if (_matches.isNotEmpty && _currentMatch > 0) {
      final match = _matches[_currentMatch - 1];
      widget.controller.selection = match;
    }
  }

  void _findNext() {
    if (_matches.isNotEmpty) {
      setState(() {
        _currentMatch = _currentMatch < _totalMatches ? _currentMatch + 1 : 1;
      });
      _highlightCurrentMatch();
      HapticFeedback.selectionClick();
    }
  }

  void _findPrevious() {
    if (_matches.isNotEmpty) {
      setState(() {
        _currentMatch = _currentMatch > 1 ? _currentMatch - 1 : _totalMatches;
      });
      _highlightCurrentMatch();
      HapticFeedback.selectionClick();
    }
  }

  void _replaceCurrentMatch() {
    if (_matches.isNotEmpty && _currentMatch > 0) {
      final match = _matches[_currentMatch - 1];
      final newText = widget.controller.text.replaceRange(
        match.start,
        match.end,
        _replaceController.text,
      );

      widget.controller.text = newText;
      widget.controller.selection = TextSelection.collapsed(
        offset: match.start + _replaceController.text.length,
      );

      HapticFeedback.mediumImpact();
      _findMatches(); // Refresh matches
    }
  }

  void _replaceAll() {
    if (_matches.isNotEmpty) {
      String newText = widget.controller.text;
      final replaceText = _replaceController.text;

      // Replace from end to start to maintain correct indices
      for (int i = _matches.length - 1; i >= 0; i--) {
        final match = _matches[i];
        newText = newText.replaceRange(match.start, match.end, replaceText);
      }

      widget.controller.text = newText;
      widget.controller.selection = TextSelection.collapsed(offset: 0);

      HapticFeedback.heavyImpact();

      // Show confirmation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Replaced ${_matches.length} occurrences'),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );

      _findMatches(); // Refresh matches
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Find Row
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _findController,
                  focusNode: _findFocusNode,
                  decoration: InputDecoration(
                    hintText: 'Find',
                    prefixIcon: CustomIconWidget(
                      iconName: 'search',
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      size: 20,
                    ),
                    suffixIcon: _findController.text.isNotEmpty
                        ? IconButton(
                            onPressed: () {
                              _findController.clear();
                              _findMatches();
                            },
                            icon: CustomIconWidget(
                              iconName: 'clear',
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceVariant,
                              size: 20,
                            ),
                          )
                        : null,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: Theme.of(context).colorScheme.outline,
                        width: 0.5,
                      ),
                    ),
                  ),
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _findNext(),
                ),
              ),

              SizedBox(width: 2.w),

              // Match Counter
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _totalMatches > 0 ? '$_currentMatch/$_totalMatches' : '0/0',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ),

              SizedBox(width: 2.w),

              // Navigation Buttons
              IconButton(
                onPressed: _matches.isNotEmpty ? _findPrevious : null,
                icon: CustomIconWidget(
                  iconName: 'keyboard_arrow_up',
                  color: _matches.isNotEmpty
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                  size: 24,
                ),
                tooltip: 'Previous',
              ),

              IconButton(
                onPressed: _matches.isNotEmpty ? _findNext : null,
                icon: CustomIconWidget(
                  iconName: 'keyboard_arrow_down',
                  color: _matches.isNotEmpty
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                  size: 24,
                ),
                tooltip: 'Next',
              ),

              // Toggle Replace
              IconButton(
                onPressed: () {
                  setState(() {
                    _isReplaceMode = !_isReplaceMode;
                  });
                  if (_isReplaceMode) {
                    _replaceFocusNode.requestFocus();
                  }
                },
                icon: CustomIconWidget(
                  iconName: _isReplaceMode ? 'expand_less' : 'expand_more',
                  color: Theme.of(context).colorScheme.primary,
                  size: 24,
                ),
                tooltip: 'Toggle Replace',
              ),

              // Close Button
              IconButton(
                onPressed: widget.onClose,
                icon: CustomIconWidget(
                  iconName: 'close',
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  size: 24,
                ),
                tooltip: 'Close',
              ),
            ],
          ),

          // Replace Row (if enabled)
          if (_isReplaceMode) ...[
            SizedBox(height: 1.h),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _replaceController,
                    focusNode: _replaceFocusNode,
                    decoration: InputDecoration(
                      hintText: 'Replace',
                      prefixIcon: CustomIconWidget(
                        iconName: 'find_replace',
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        size: 20,
                      ),
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(
                          color: Theme.of(context).colorScheme.outline,
                          width: 0.5,
                        ),
                      ),
                    ),
                    textInputAction: TextInputAction.done,
                  ),
                ),

                SizedBox(width: 2.w),

                // Replace Buttons
                TextButton(
                  onPressed: _matches.isNotEmpty ? _replaceCurrentMatch : null,
                  child: Text('Replace'),
                ),

                TextButton(
                  onPressed: _matches.isNotEmpty ? _replaceAll : null,
                  child: Text('All'),
                ),
              ],
            ),
          ],

          // Options Row
          SizedBox(height: 1.h),
          Row(
            children: [
              _buildOptionChip('Aa', 'Case sensitive', _caseSensitive, (value) {
                setState(() {
                  _caseSensitive = value;
                });
                _findMatches();
              }),
              SizedBox(width: 2.w),
              _buildOptionChip('\\b', 'Whole words', _wholeWords, (value) {
                setState(() {
                  _wholeWords = value;
                });
                _findMatches();
              }),
              SizedBox(width: 2.w),
              _buildOptionChip('.*', 'Regex', _useRegex, (value) {
                setState(() {
                  _useRegex = value;
                });
                _findMatches();
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOptionChip(
    String label,
    String tooltip,
    bool isSelected,
    ValueChanged<bool> onChanged,
  ) {
    return Tooltip(
      message: tooltip,
      child: FilterChip(
        label: Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
        ),
        selected: isSelected,
        onSelected: onChanged,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}
