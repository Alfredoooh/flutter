import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class EditorToolbarWidget extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback? onUndo;
  final VoidCallback? onRedo;
  final VoidCallback? onCut;
  final VoidCallback? onCopy;
  final VoidCallback? onPaste;

  const EditorToolbarWidget({
    super.key,
    required this.controller,
    this.onUndo,
    this.onRedo,
    this.onCut,
    this.onCopy,
    this.onPaste,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 6.h,
      padding: EdgeInsets.symmetric(horizontal: 2.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildToolbarButton(
            context,
            'undo',
            'Undo',
            onUndo ?? _handleUndo,
          ),
          _buildToolbarButton(
            context,
            'redo',
            'Redo',
            onRedo ?? _handleRedo,
          ),
          Container(
            width: 1,
            height: 3.h,
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
          ),
          _buildToolbarButton(
            context,
            'content_cut',
            'Cut',
            onCut ?? _handleCut,
          ),
          _buildToolbarButton(
            context,
            'content_copy',
            'Copy',
            onCopy ?? _handleCopy,
          ),
          _buildToolbarButton(
            context,
            'content_paste',
            'Paste',
            onPaste ?? _handlePaste,
          ),
        ],
      ),
    );
  }

  Widget _buildToolbarButton(
    BuildContext context,
    String iconName,
    String tooltip,
    VoidCallback onPressed,
  ) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: () {
          HapticFeedback.selectionClick();
          onPressed();
        },
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: EdgeInsets.all(2.w),
          child: CustomIconWidget(
            iconName: iconName,
            color: Theme.of(context).colorScheme.onSurface,
            size: 20,
          ),
        ),
      ),
    );
  }

  void _handleUndo() {
    // Implement undo functionality
    // This would typically work with a text history system
  }

  void _handleRedo() {
    // Implement redo functionality
    // This would typically work with a text history system
  }

  void _handleCut() {
    final selection = controller.selection;
    if (selection.isValid && !selection.isCollapsed) {
      final selectedText = controller.text.substring(
        selection.start,
        selection.end,
      );
      Clipboard.setData(ClipboardData(text: selectedText));
      controller.text = controller.text.replaceRange(
        selection.start,
        selection.end,
        '',
      );
      controller.selection = TextSelection.collapsed(offset: selection.start);
    }
  }

  void _handleCopy() {
    final selection = controller.selection;
    if (selection.isValid && !selection.isCollapsed) {
      final selectedText = controller.text.substring(
        selection.start,
        selection.end,
      );
      Clipboard.setData(ClipboardData(text: selectedText));
    }
  }

  void _handlePaste() async {
    final clipboardData = await Clipboard.getData('text/plain');
    if (clipboardData?.text != null) {
      final selection = controller.selection;
      final newText = controller.text.replaceRange(
        selection.start,
        selection.end,
        clipboardData!.text!,
      );
      controller.text = newText;
      controller.selection = TextSelection.collapsed(
        offset: selection.start + clipboardData.text!.length,
      );
    }
  }
}
