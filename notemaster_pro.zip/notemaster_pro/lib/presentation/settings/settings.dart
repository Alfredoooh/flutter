import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/font_size_slider_widget.dart';
import './widgets/language_selector_widget.dart';
import './widgets/settings_item_widget.dart';
import './widgets/settings_section_widget.dart';
import './widgets/storage_usage_widget.dart';
import './widgets/theme_selector_widget.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  // Settings state variables
  bool _isDarkMode = false;
  bool _isAutoTheme = true;
  double _fontSize = 16.0;
  String _selectedLanguage = 'English';
  bool _autoSave = true;
  int _autoSaveInterval = 30;
  bool _spellCheck = true;
  bool _syntaxHighlighting = true;
  bool _biometricAuth = false;
  bool _noteEncryption = false;
  bool _privacyMode = false;
  bool _debugMode = false;
  bool _betaFeatures = false;

  // Mock data for settings
  final List<Map<String, dynamic>> _languages = [
    {'name': 'English', 'code': 'en', 'rtl': false},
    {'name': 'العربية', 'code': 'ar', 'rtl': true},
    {'name': 'Español', 'code': 'es', 'rtl': false},
    {'name': 'Français', 'code': 'fr', 'rtl': false},
    {'name': 'Deutsch', 'code': 'de', 'rtl': false},
    {'name': 'हिन्दी', 'code': 'hi', 'rtl': false},
    {'name': '中文', 'code': 'zh', 'rtl': false},
    {'name': '日本語', 'code': 'ja', 'rtl': false},
  ];

  final Map<String, dynamic> _storageInfo = {
    'totalSpace': '64 GB',
    'usedSpace': '12.5 GB',
    'appData': '2.3 GB',
    'notes': '1.8 GB',
    'cache': '0.5 GB',
    'usage': 0.65,
  };

  final Map<String, dynamic> _appInfo = {
    'version': '2.1.0',
    'buildNumber': '210',
    'lastUpdate': '2024-01-15',
    'developer': 'NoteMaster Team',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Settings',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back_ios',
            color: Theme.of(context).colorScheme.onSurface,
            size: 20,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _showSearchSettings,
            icon: CustomIconWidget(
              iconName: 'search',
              color: Theme.of(context).colorScheme.onSurface,
              size: 24,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            SizedBox(height: 2.h),

            // General Section
            SettingsSectionWidget(
              title: 'General',
              children: [
                ThemeSelectorWidget(
                  isDarkMode: _isDarkMode,
                  isAutoTheme: _isAutoTheme,
                  onThemeChanged: (isDark, isAuto) {
                    setState(() {
                      _isDarkMode = isDark;
                      _isAutoTheme = isAuto;
                    });
                  },
                ),
                FontSizeSliderWidget(
                  fontSize: _fontSize,
                  onFontSizeChanged: (size) {
                    setState(() {
                      _fontSize = size;
                    });
                  },
                ),
                LanguageSelectorWidget(
                  selectedLanguage: _selectedLanguage,
                  languages: _languages,
                  onLanguageChanged: (language) {
                    setState(() {
                      _selectedLanguage = language;
                    });
                  },
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Editor Preferences Section
            SettingsSectionWidget(
              title: 'Editor Preferences',
              children: [
                SettingsItemWidget(
                  title: 'Auto-save',
                  subtitle: 'Automatically save changes',
                  trailing: Switch.adaptive(
                    value: _autoSave,
                    onChanged: (value) {
                      setState(() {
                        _autoSave = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Auto-save Interval',
                  subtitle: '$_autoSaveInterval seconds',
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showAutoSaveIntervalPicker(),
                ),
                SettingsItemWidget(
                  title: 'Spell Check',
                  subtitle: 'Check spelling while typing',
                  trailing: Switch.adaptive(
                    value: _spellCheck,
                    onChanged: (value) {
                      setState(() {
                        _spellCheck = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Syntax Highlighting',
                  subtitle: 'Highlight code syntax',
                  trailing: Switch.adaptive(
                    value: _syntaxHighlighting,
                    onChanged: (value) {
                      setState(() {
                        _syntaxHighlighting = value;
                      });
                    },
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Security Section
            SettingsSectionWidget(
              title: 'Security & Privacy',
              children: [
                SettingsItemWidget(
                  title: 'Biometric Authentication',
                  subtitle: 'Use fingerprint or face unlock',
                  leading: CustomIconWidget(
                    iconName: 'fingerprint',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: Switch.adaptive(
                    value: _biometricAuth,
                    onChanged: (value) {
                      setState(() {
                        _biometricAuth = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Note Encryption',
                  subtitle: 'Encrypt sensitive notes',
                  leading: CustomIconWidget(
                    iconName: 'lock',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: Switch.adaptive(
                    value: _noteEncryption,
                    onChanged: (value) {
                      setState(() {
                        _noteEncryption = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Privacy Mode',
                  subtitle: 'Hide sensitive content in app switcher',
                  leading: CustomIconWidget(
                    iconName: 'visibility_off',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: Switch.adaptive(
                    value: _privacyMode,
                    onChanged: (value) {
                      setState(() {
                        _privacyMode = value;
                      });
                    },
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Storage Management Section
            SettingsSectionWidget(
              title: 'Storage Management',
              children: [
                StorageUsageWidget(storageInfo: _storageInfo),
                SettingsItemWidget(
                  title: 'Clear Cache',
                  subtitle: "Free up ${_storageInfo['cache']} of space",
                  leading: CustomIconWidget(
                    iconName: 'delete_sweep',
                    color: Theme.of(context).colorScheme.error,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showClearCacheDialog(),
                ),
                SettingsItemWidget(
                  title: 'Backup & Restore',
                  subtitle: 'Manage your data backups',
                  leading: CustomIconWidget(
                    iconName: 'backup',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showBackupOptions(),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Import/Export Section
            SettingsSectionWidget(
              title: 'Data Management',
              children: [
                SettingsItemWidget(
                  title: 'Export Notes',
                  subtitle: 'Export all notes to file',
                  leading: CustomIconWidget(
                    iconName: 'file_upload',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showExportOptions(),
                ),
                SettingsItemWidget(
                  title: 'Import Notes',
                  subtitle: 'Import notes from file',
                  leading: CustomIconWidget(
                    iconName: 'file_download',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showImportOptions(),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Advanced Section
            SettingsSectionWidget(
              title: 'Advanced',
              children: [
                SettingsItemWidget(
                  title: 'Debug Mode',
                  subtitle: 'Enable debugging features',
                  leading: CustomIconWidget(
                    iconName: 'bug_report',
                    color: Theme.of(context).colorScheme.secondary,
                    size: 24,
                  ),
                  trailing: Switch.adaptive(
                    value: _debugMode,
                    onChanged: (value) {
                      setState(() {
                        _debugMode = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Beta Features',
                  subtitle: 'Try experimental features',
                  leading: CustomIconWidget(
                    iconName: 'science',
                    color: Theme.of(context).colorScheme.secondary,
                    size: 24,
                  ),
                  trailing: Switch.adaptive(
                    value: _betaFeatures,
                    onChanged: (value) {
                      setState(() {
                        _betaFeatures = value;
                      });
                    },
                  ),
                ),
                SettingsItemWidget(
                  title: 'Performance Settings',
                  subtitle: 'Optimize app performance',
                  leading: CustomIconWidget(
                    iconName: 'speed',
                    color: Theme.of(context).colorScheme.secondary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showPerformanceSettings(),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // About Section
            SettingsSectionWidget(
              title: 'About',
              children: [
                SettingsItemWidget(
                  title: 'App Version',
                  subtitle:
                      "Version ${_appInfo['version']} (${_appInfo['buildNumber']})",
                  leading: CustomIconWidget(
                    iconName: 'info',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                ),
                SettingsItemWidget(
                  title: 'What\'s New',
                  subtitle: "What's New in v${_appInfo['version']}",
                  leading: CustomIconWidget(
                    iconName: 'new_releases',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showChangelog(),
                ),
                SettingsItemWidget(
                  title: 'Help & Support',
                  subtitle: 'Get help and documentation',
                  leading: CustomIconWidget(
                    iconName: 'help',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showHelpAndSupport(),
                ),
                SettingsItemWidget(
                  title: 'Send Feedback',
                  subtitle: 'Share your thoughts with us',
                  leading: CustomIconWidget(
                    iconName: 'feedback',
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  trailing: CustomIconWidget(
                    iconName: 'chevron_right',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                  onTap: () => _showFeedbackForm(),
                ),
              ],
            ),

            SizedBox(height: 5.h),
          ],
        ),
      ),
    );
  }

  void _showSearchSettings() {
    showSearch(
      context: context,
      delegate: SettingsSearchDelegate(),
    );
  }

  void _showAutoSaveIntervalPicker() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        height: 40.h,
        padding: EdgeInsets.all(4.w),
        child: Column(
          children: [
            Text(
              'Auto-save Interval',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 2.h),
            Expanded(
              child: ListView.builder(
                itemCount: 6,
                itemBuilder: (context, index) {
                  final intervals = [10, 30, 60, 120, 300, 600];
                  final labels = [
                    '10 seconds',
                    '30 seconds',
                    '1 minute',
                    '2 minutes',
                    '5 minutes',
                    '10 minutes'
                  ];
                  final interval = intervals[index];
                  final label = labels[index];

                  return ListTile(
                    title: Text(label),
                    trailing: _autoSaveInterval == interval
                        ? CustomIconWidget(
                            iconName: 'check',
                            color: Theme.of(context).colorScheme.primary,
                            size: 24,
                          )
                        : null,
                    onTap: () {
                      setState(() {
                        _autoSaveInterval = interval;
                      });
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showClearCacheDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Clear Cache'),
        content: Text(
            "This will free up ${_storageInfo['cache']} of space. This action cannot be undone."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _clearCache();
            },
            child: Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _clearCache() {
    // Simulate cache clearing
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Cache cleared successfully'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _showBackupOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Backup & Restore',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'cloud_upload',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Create Backup'),
              subtitle: Text('Backup all your notes and settings'),
              onTap: () {
                Navigator.pop(context);
                _createBackup();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'cloud_download',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Restore from Backup'),
              subtitle: Text('Restore notes from a backup file'),
              onTap: () {
                Navigator.pop(context);
                _restoreBackup();
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _createBackup() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Backup created successfully'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _restoreBackup() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Backup restored successfully'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Export Format',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'description',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('PDF'),
              subtitle: Text('Export as PDF document'),
              onTap: () {
                Navigator.pop(context);
                _exportAsPDF();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'code',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Markdown'),
              subtitle: Text('Export as Markdown files'),
              onTap: () {
                Navigator.pop(context);
                _exportAsMarkdown();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'article',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Plain Text'),
              subtitle: Text('Export as text files'),
              onTap: () {
                Navigator.pop(context);
                _exportAsText();
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _exportAsPDF() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notes exported as PDF'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _exportAsMarkdown() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notes exported as Markdown'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _exportAsText() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notes exported as text files'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _showImportOptions() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Import functionality coming soon'),
        backgroundColor: Theme.of(context).colorScheme.secondary,
      ),
    );
  }

  void _showPerformanceSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: Text('Performance Settings')),
          body: Center(child: Text('Performance Settings Screen')),
        ),
      ),
    );
  }

  void _showChangelog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('What\'s New in v${_appInfo['version']}'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('• Enhanced text editor with better performance'),
              SizedBox(height: 1.h),
              Text('• New trading recovery calculator'),
              SizedBox(height: 1.h),
              Text('• Improved dark mode support'),
              SizedBox(height: 1.h),
              Text('• Bug fixes and stability improvements'),
              SizedBox(height: 1.h),
              Text('• Better accessibility features'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showHelpAndSupport() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: Text('Help & Support')),
          body: Center(child: Text('Help & Support Screen')),
        ),
      ),
    );
  }

  void _showFeedbackForm() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: Text('Send Feedback')),
          body: Center(child: Text('Feedback Form Screen')),
        ),
      ),
    );
  }
}

class SettingsSearchDelegate extends SearchDelegate {
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () => query = '',
        icon: CustomIconWidget(
          iconName: 'clear',
          color: Theme.of(context).colorScheme.onSurface,
          size: 24,
        ),
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () => close(context, null),
      icon: CustomIconWidget(
        iconName: 'arrow_back',
        color: Theme.of(context).colorScheme.onSurface,
        size: 24,
      ),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildSearchResults();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return _buildSearchResults();
  }

  Widget _buildSearchResults() {
    final searchResults = [
      'Theme',
      'Font Size',
      'Language',
      'Auto-save',
      'Spell Check',
      'Biometric',
      'Encryption',
      'Storage',
      'Backup',
      'Export',
      'Debug Mode',
    ]
        .where((item) => item.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return ListView.builder(
      itemCount: searchResults.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(searchResults[index]),
          onTap: () {
            close(context, searchResults[index]);
          },
        );
      },
    );
  }
}
