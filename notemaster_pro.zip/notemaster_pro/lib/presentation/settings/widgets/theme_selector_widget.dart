import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class ThemeSelectorWidget extends StatelessWidget {
  final bool isDarkMode;
  final bool isAutoTheme;
  final Function(bool isDark, bool isAuto) onThemeChanged;

  const ThemeSelectorWidget({
    super.key,
    required this.isDarkMode,
    required this.isAutoTheme,
    required this.onThemeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => _showThemeSelector(context),
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: isAutoTheme
                  ? 'brightness_auto'
                  : isDarkMode
                      ? 'dark_mode'
                      : 'light_mode',
              color: Theme.of(context).colorScheme.primary,
              size: 24,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Theme',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    isAutoTheme
                        ? 'System default'
                        : isDarkMode
                            ? 'Dark mode'
                            : 'Light mode',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'chevron_right',
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  void _showThemeSelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Choose Theme',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'light_mode',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Light'),
              trailing: !isAutoTheme && !isDarkMode
                  ? CustomIconWidget(
                      iconName: 'check',
                      color: Theme.of(context).colorScheme.primary,
                      size: 24,
                    )
                  : null,
              onTap: () {
                onThemeChanged(false, false);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'dark_mode',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('Dark'),
              trailing: !isAutoTheme && isDarkMode
                  ? CustomIconWidget(
                      iconName: 'check',
                      color: Theme.of(context).colorScheme.primary,
                      size: 24,
                    )
                  : null,
              onTap: () {
                onThemeChanged(true, false);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'brightness_auto',
                color: Theme.of(context).colorScheme.primary,
                size: 24,
              ),
              title: Text('System Default'),
              trailing: isAutoTheme
                  ? CustomIconWidget(
                      iconName: 'check',
                      color: Theme.of(context).colorScheme.primary,
                      size: 24,
                    )
                  : null,
              onTap: () {
                onThemeChanged(false, true);
                Navigator.pop(context);
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
