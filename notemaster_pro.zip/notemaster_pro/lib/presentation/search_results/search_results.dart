import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './widgets/recent_searches_widget.dart';
import './widgets/search_filter_widget.dart';
import './widgets/search_result_card_widget.dart';
import './widgets/search_suggestions_widget.dart';

class SearchResults extends StatefulWidget {
  const SearchResults({super.key});

  @override
  State<SearchResults> createState() => _SearchResultsState();
}

class _SearchResultsState extends State<SearchResults>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  bool _isSearching = false;
  bool _showFilters = false;
  bool _showSuggestions = false;
  String _selectedFilter = 'All';
  String _selectedDateRange = 'Any time';
  List<String> _searchHistory = [];
  List<Map<String, dynamic>> _searchResults = [];
  List<String> _searchSuggestions = [];

  // Mock data for search results
  final List<Map<String, dynamic>> _mockNotes = [
    {
      "id": 1,
      "title": "Flutter Development Notes",
      "content":
          "Flutter is Google's UI toolkit for building natively compiled applications for mobile, web, and desktop from a single codebase. Key concepts include widgets, state management, and the widget tree.",
      "filePath": "Development/Flutter/basics.md",
      "lastModified": DateTime.now().subtract(Duration(hours: 2)),
      "category": "Development",
      "tags": ["flutter", "mobile", "development"],
      "type": "note"
    },
    {
      "id": 2,
      "title": "Trading Strategy Analysis",
      "content":
          "Risk management is crucial in trading. Never risk more than 2% of your portfolio on a single trade. Use stop-loss orders to limit potential losses and take-profit orders to secure gains.",
      "filePath": "Finance/Trading/risk_management.md",
      "lastModified": DateTime.now().subtract(Duration(days: 1)),
      "category": "Finance",
      "tags": ["trading", "risk", "strategy"],
      "type": "note"
    },
    {
      "id": 3,
      "title": "Meeting Notes - Project Alpha",
      "content":
          "Discussed project timeline and deliverables. Key action items: complete UI mockups by Friday, finalize API endpoints, and schedule user testing sessions for next week.",
      "filePath": "Work/Meetings/project_alpha_meeting.md",
      "lastModified": DateTime.now().subtract(Duration(hours: 6)),
      "category": "Work",
      "tags": ["meeting", "project", "alpha"],
      "type": "note"
    },
    {
      "id": 4,
      "title": "Recipe Collection",
      "content":
          "Homemade pasta recipe: 2 cups flour, 3 eggs, 1 tsp salt. Mix ingredients, knead for 10 minutes, rest for 30 minutes, then roll and cut into desired shapes.",
      "filePath": "Personal/Recipes/pasta.md",
      "lastModified": DateTime.now().subtract(Duration(days: 3)),
      "category": "Personal",
      "tags": ["recipe", "cooking", "pasta"],
      "type": "note"
    },
    {
      "id": 5,
      "title": "Book Summary - Clean Code",
      "content":
          "Clean code is code that is easy to read, understand, and modify. Key principles include meaningful names, small functions, and proper error handling. Always write code as if the person maintaining it is a violent psychopath who knows where you live.",
      "filePath": "Learning/Books/clean_code_summary.md",
      "lastModified": DateTime.now().subtract(Duration(days: 2)),
      "category": "Learning",
      "tags": ["book", "programming", "clean code"],
      "type": "note"
    }
  ];

  final List<String> _mockSearchHistory = [
    "flutter widgets",
    "trading strategy",
    "meeting notes",
    "clean code principles",
    "recipe pasta"
  ];

  final List<String> _mockSuggestions = [
    "flutter development",
    "flutter widgets",
    "flutter state management",
    "flutter navigation",
    "flutter animations"
  ];

  @override
  void initState() {
    super.initState();
    _searchHistory = List.from(_mockSearchHistory);
    _searchController.addListener(_onSearchChanged);
    _searchFocusNode.addListener(_onFocusChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text;
    setState(() {
      _showSuggestions = query.isNotEmpty && _searchFocusNode.hasFocus;
      if (query.isNotEmpty) {
        _searchSuggestions = _mockSuggestions
            .where((suggestion) =>
                suggestion.toLowerCase().contains(query.toLowerCase()))
            .toList();
      } else {
        _searchSuggestions.clear();
      }
    });

    if (query.isNotEmpty) {
      _performSearch(query);
    } else {
      setState(() {
        _searchResults.clear();
      });
    }
  }

  void _onFocusChanged() {
    setState(() {
      _showSuggestions =
          _searchController.text.isNotEmpty && _searchFocusNode.hasFocus;
    });
  }

  void _performSearch(String query) {
    setState(() {
      _isSearching = true;
    });

    // Simulate search delay
    Future.delayed(Duration(milliseconds: 300), () {
      final results = _mockNotes.where((note) {
        final titleMatch = (note["title"] as String)
            .toLowerCase()
            .contains(query.toLowerCase());
        final contentMatch = (note["content"] as String)
            .toLowerCase()
            .contains(query.toLowerCase());
        final categoryMatch = _selectedFilter == 'All' ||
            (note["category"] as String) == _selectedFilter;

        return (titleMatch || contentMatch) && categoryMatch;
      }).toList();

      // Sort by relevance (title matches first)
      results.sort((a, b) {
        final aTitle =
            (a["title"] as String).toLowerCase().contains(query.toLowerCase());
        final bTitle =
            (b["title"] as String).toLowerCase().contains(query.toLowerCase());

        if (aTitle && !bTitle) return -1;
        if (!aTitle && bTitle) return 1;
        return 0;
      });

      setState(() {
        _searchResults = results;
        _isSearching = false;
      });
    });
  }

  void _addToSearchHistory(String query) {
    if (query.isNotEmpty && !_searchHistory.contains(query)) {
      setState(() {
        _searchHistory.insert(0, query);
        if (_searchHistory.length > 10) {
          _searchHistory.removeLast();
        }
      });
    }
  }

  void _clearSearch() {
    setState(() {
      _searchController.clear();
      _searchResults.clear();
      _showSuggestions = false;
    });
  }

  void _selectSuggestion(String suggestion) {
    _searchController.text = suggestion;
    _searchFocusNode.unfocus();
    _addToSearchHistory(suggestion);
    _performSearch(suggestion);
  }

  void _selectRecentSearch(String query) {
    _searchController.text = query;
    _performSearch(query);
  }

  void _toggleFilters() {
    setState(() {
      _showFilters = !_showFilters;
    });
  }

  void _applyFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
    });
    if (_searchController.text.isNotEmpty) {
      _performSearch(_searchController.text);
    }
  }

  void _openNote(Map<String, dynamic> note) {
    // Add search term to history
    _addToSearchHistory(_searchController.text);

    // Navigate to note editor with the selected note
    Navigator.pushNamed(context, '/note-editor', arguments: {
      'noteId': note['id'],
      'searchTerm': _searchController.text,
    });
  }

  void _exportResults() {
    // Show export options
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        title: Text('Export Search Results'),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              // Implement PDF export
            },
            child: Text('Export as PDF'),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              // Implement text export
            },
            child: Text('Export as Text'),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              // Implement share functionality
            },
            child: Text('Share Results'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          width: 0.5,
        ),
      ),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.only(left: 4.w),
            child: CustomIconWidget(
              iconName: 'search',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
          Expanded(
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              decoration: InputDecoration(
                hintText: 'Search notes, content, and more...',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 3.w,
                  vertical: 1.5.h,
                ),
                hintStyle: TextStyle(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  fontSize: 14.sp,
                ),
              ),
              style: TextStyle(
                fontSize: 14.sp,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
            ),
          ),
          if (_searchController.text.isNotEmpty)
            GestureDetector(
              onTap: _clearSearch,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 2.w),
                child: CustomIconWidget(
                  iconName: 'clear',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 18,
                ),
              ),
            ),
          GestureDetector(
            onTap: _toggleFilters,
            child: Container(
              padding: EdgeInsets.all(2.w),
              margin: EdgeInsets.only(right: 2.w),
              decoration: BoxDecoration(
                color: _showFilters
                    ? AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: 'tune',
                color: _showFilters
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_showSuggestions && _searchSuggestions.isNotEmpty) {
      return SearchSuggestionsWidget(
        suggestions: _searchSuggestions,
        onSuggestionTap: _selectSuggestion,
      );
    }

    if (_searchController.text.isEmpty) {
      return _buildEmptyState();
    }

    if (_isSearching) {
      return _buildLoadingState();
    }

    if (_searchResults.isEmpty) {
      return _buildNoResultsState();
    }

    return _buildSearchResults();
  }

  Widget _buildEmptyState() {
    return Column(
      children: [
        if (_searchHistory.isNotEmpty)
          RecentSearchesWidget(
            searches: _searchHistory,
            onSearchTap: _selectRecentSearch,
            onClearHistory: () {
              setState(() {
                _searchHistory.clear();
              });
            },
          ),
        Expanded(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'search',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 64,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Start typing to search',
                  style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Search across all your notes and content',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CupertinoActivityIndicator(
            radius: 20,
            color: AppTheme.lightTheme.colorScheme.primary,
          ),
          SizedBox(height: 2.h),
          Text(
            'Searching...',
            style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'search_off',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 64,
          ),
          SizedBox(height: 2.h),
          Text(
            'No results found',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Try adjusting your search terms or filters',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          TextButton(
            onPressed: _clearSearch,
            child: Text('Clear Search'),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    return Column(
      children: [
        // Results header
        Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${_searchResults.length} result${_searchResults.length == 1 ? '' : 's'}',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              TextButton(
                onPressed: _exportResults,
                child: Text('Export'),
              ),
            ],
          ),
        ),
        // Results list
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            itemCount: _searchResults.length,
            itemBuilder: (context, index) {
              final result = _searchResults[index];
              return SearchResultCardWidget(
                result: result,
                searchTerm: _searchController.text,
                onTap: () => _openNote(result),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                width: 0.5,
              ),
            ),
            child: CustomIconWidget(
              iconName: 'arrow_back_ios',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 18,
            ),
          ),
        ),
        title: Text(
          'Search',
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          if (_searchResults.isNotEmpty)
            GestureDetector(
              onTap: () {
                // Voice search functionality
                showCupertinoDialog(
                  context: context,
                  builder: (context) => CupertinoAlertDialog(
                    title: Text('Voice Search'),
                    content: Text('Voice search feature coming soon!'),
                    actions: [
                      CupertinoDialogAction(
                        onPressed: () => Navigator.pop(context),
                        child: Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              child: Container(
                margin: EdgeInsets.only(right: 4.w),
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.2),
                    width: 0.5,
                  ),
                ),
                child: CustomIconWidget(
                  iconName: 'mic',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 18,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          _buildSearchBar(),
          if (_showFilters)
            SearchFilterWidget(
              selectedFilter: _selectedFilter,
              selectedDateRange: _selectedDateRange,
              onFilterChanged: _applyFilter,
              onDateRangeChanged: (dateRange) {
                setState(() {
                  _selectedDateRange = dateRange;
                });
                if (_searchController.text.isNotEmpty) {
                  _performSearch(_searchController.text);
                }
              },
            ),
          Expanded(child: _buildContent()),
        ],
      ),
    );
  }
}
