import 'package:flutter/material.dart';
import '../presentation/main_dashboard/main_dashboard.dart';
import '../presentation/notes_list/notes_list.dart';
import '../presentation/settings/settings.dart';
import '../presentation/trading_recovery_calculator/trading_recovery_calculator.dart';
import '../presentation/search_results/search_results.dart';
import '../presentation/note_editor/note_editor.dart';

class AppRoutes {
  static const String initial = '/';
  static const String mainDashboard = '/main-dashboard';
  static const String noteEditor = '/note-editor';
  static const String tradingRecoveryCalculator =
      '/trading-recovery-calculator';
  static const String notesList = '/notes-list';
  static const String searchResults = '/search-results';
  static const String settings = '/settings';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const MainDashboard(),
    mainDashboard: (context) => const MainDashboard(),
    noteEditor: (context) => const NoteEditor(),
    tradingRecoveryCalculator: (context) => const TradingRecoveryCalculator(),
    notesList: (context) => const NotesList(),
    searchResults: (context) => const SearchResults(),
    settings: (context) => const Settings(),
  };
}
